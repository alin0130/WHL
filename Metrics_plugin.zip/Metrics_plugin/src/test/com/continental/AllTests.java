package com.continental;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.continental.MetricsPlugin.MetricsPluginPublisherTest;
import com.continental.utilities.PropertiesReaderTest;

@RunWith(Suite.class)
@SuiteClasses({ MetricsPluginPublisherTest.class, PropertiesReaderTest.class })
public class AllTests {

}
