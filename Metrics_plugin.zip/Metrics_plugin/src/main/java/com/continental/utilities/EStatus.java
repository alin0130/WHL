package com.continental.utilities;

public enum EStatus {
	SUCCESS, FAILURE;
}
