package com.continental.utilities;

import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.util.RunList;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Logger;

import static com.continental.MetricsPlugin.EMetricsModelType.K5;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.xml_parser.BuildReportsParser;
import com.continental.xml_parser.CodingRulesDeviationsAbsoluteParsers;
import com.continental.xml_parser.CodingRulesDeviationsPerElocParser;
import com.continental.xml_parser.CycloComplexParser;
import com.continental.xml_parser.ElocParser;
import com.continental.xml_parser.K2parser;
import com.continental.xml_parser.K3Parser;
import com.continental.xml_parser.K4Parser;
import com.continental.xml_parser.K5Parser;
import com.continental.xml_parser.K5ParserIterateBuilds;
import com.continental.xml_parser.MemoryReportsParser;
import com.continental.xml_parser.MisraAdvisoryRecommendedParser;
import com.continental.xml_parser.MisraRequiredObligatoryParser;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;

public class ProjectMetricsJobIterator {

  private static final int THREADS_NUMBER = 12;
  private AbstractProject<?, ?> project;
  private MetricsModel metricsModel;
  private AbstractBuild<?, ?> build;
  MetricsUtilities mu= new MetricsUtilities();
  private String type;
  private static final Logger LOG = Logger.getLogger(K5Parser.class.getName());
  /**
   * Instantiates a new project metrics job iterator.
   *
   * @param project the project
   * @param metricsModel the metrics model
   * @param type the type
   * Eus: These are the constructors for this class, it receives the Project, the Metrics Model and the
   * Type (string): MISRA ->Misra (MetricsPluginAction)  KPIS -> KPI's Metrics (KMetricsAction)
   */
  public ProjectMetricsJobIterator(AbstractProject<?, ?> project, MetricsModel metricsModel, String type) {
    this.metricsModel = metricsModel;
    this.project = project;
    this.type = type;
  }

  public ProjectMetricsJobIterator(AbstractBuild<?, ?> build, MetricsModel metricsModel, String type) {
    this.metricsModel = metricsModel;
    this.build = build;
    this.type = type;
  }
  
	private File createNewFile(File oldFile, String newFileName) {
		File pathFile = new File(oldFile, GlobalProperties.METRICS_FOLDER);
		File newFile = new File(pathFile, newFileName);
		return newFile;
	}

  /**
   * Adds the build to model.
   *
   * @param logger the logger
   */
  public void addBuildToModel(PrintStream logger) {
    PropertiesReader propertiesReader = new PropertiesReader();
	ArrayList<File> projectFiles = new ArrayList<File>();
    File projectMetricsFile = build.getRootDir();
    
    projectFiles.add(createNewFile(projectMetricsFile, GlobalProperties.PROJECT_METRICS_XML_FILE));
    projectFiles.add(createNewFile(projectMetricsFile, GlobalProperties.DOORS_FILE));
    
    startThreads(projectFiles, propertiesReader, build, logger);
  }

  /**
   * Iterate on builds and start parser.
   */
  public void iterateOnBuildsAndStartParser() {
    File projectMetricsFile;
    final String K5_FILE="K5.txt";
    
    PropertiesReader propertiesReader = new PropertiesReader();
    RunList<?> buildsList = project.getBuilds();
    ListIterator<?> listIterator = buildsList.listIterator();
    
    while (listIterator.hasNext()) {
      AbstractBuild<?, ?> nextBuild = (AbstractBuild<?, ?>) listIterator.next();
      ArrayList<File> projectFiles = new ArrayList<File>();
      projectMetricsFile = nextBuild.getRootDir();
      projectFiles.add(createNewFile(projectMetricsFile, GlobalProperties.PROJECT_METRICS_XML_FILE));
      projectFiles.add(createNewFile(projectMetricsFile, K5_FILE));
      if (!projectFiles.get(0).exists()) {
        continue;
      }
      startThreadsIterateOnBuilds(projectFiles, propertiesReader, nextBuild);
    }
  }

  /**
   * Start threads.
   *
   * @param projectFiles the project files
   * @param propertiesReader the properties reader
   * @param build the build
   * @param logger the logger
   */
  private void startThreads(ArrayList<File> projectFiles, PropertiesReader propertiesReader, AbstractBuild<?, ?> build, PrintStream logger) {
	File projectMetricsFile=projectFiles.get(0);
	File projectMetricsFileDoors= projectFiles.get(1);
	ResultsSaver saver= new ResultsSaver(build);
	String doorsfileName = saver.getSourceFileName(projectMetricsFileDoors.toString());
	
    ListeningExecutorService threadPool = MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(THREADS_NUMBER));

    List<Callable<Void>> lista = new ArrayList<Callable<Void>>();
	LOG.info("Started Metrics threads");
    if(type.equals("MISRA")){
    	LOG.info("MISRA Started");
    	lista.add(new MemoryReportsParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new BuildReportsParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new CodingRulesDeviationsPerElocParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new CodingRulesDeviationsAbsoluteParsers(projectMetricsFile, propertiesReader, build,metricsModel));
	    lista.add(new CycloComplexParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new ElocParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new MisraRequiredObligatoryParser(projectMetricsFile, propertiesReader, build, metricsModel));
        lista.add(new MisraAdvisoryRecommendedParser(projectMetricsFile, propertiesReader, build, metricsModel));
    } 
    else {
    	LOG.info("KPIs Started");
    	lista.add(new K2parser(projectMetricsFile, propertiesReader, build, metricsModel, logger));
    //doors file containing data for K5 doesn't exists. "KPI" is the last folder from location containing the reports
	if (!("KPI".equals(doorsfileName) || "".equals(doorsfileName))) {
		lista.add(new K5Parser(projectMetricsFileDoors, propertiesReader, build, metricsModel, logger));
	}

    	lista.add(new K3Parser(projectMetricsFile, propertiesReader, build, metricsModel, logger));
    	lista.add(new K4Parser(projectMetricsFile, propertiesReader, build, metricsModel, logger));
    
    }
	
    try {
      List<Future<Void>> invokeAll = threadPool.invokeAll(lista);
      for (Future<Void> future : invokeAll) {
        try {
          future.get();
        } catch (ExecutionException e) {
          e.printStackTrace();
        }
      }
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    threadPool.shutdownNow();
  }
  
  private void startThreadsIterateOnBuilds(ArrayList<File> projectFiles, PropertiesReader propertiesReader, AbstractBuild<?, ?> build) {
	File projectMetricsFile=projectFiles.get(0);
	File projectK5File= projectFiles.get(1);
	
    ListeningExecutorService threadPool = MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(THREADS_NUMBER));
    List<Callable<Void>> lista = new ArrayList<Callable<Void>>();
    
    if(type.equals("MISRA")){
	    LOG.info("MISRA Started");
	    lista.add(new MemoryReportsParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new BuildReportsParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new CodingRulesDeviationsPerElocParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new CodingRulesDeviationsAbsoluteParsers(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new CycloComplexParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new ElocParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new MisraRequiredObligatoryParser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new MisraAdvisoryRecommendedParser(projectMetricsFile, propertiesReader, build, metricsModel));   
    } else {
	    lista.add(new K2parser(projectMetricsFile, propertiesReader, build, metricsModel));
	    if (projectK5File.exists()) {
	    	lista.add(new K5ParserIterateBuilds(projectK5File, propertiesReader, build, metricsModel));
	    }
	    lista.add(new K3Parser(projectMetricsFile, propertiesReader, build, metricsModel));
	    lista.add(new K4Parser(projectMetricsFile, propertiesReader, build, metricsModel));
    }
    try {
      List<Future<Void>> invokeAll = threadPool.invokeAll(lista);
      for (Future<Void> future : invokeAll) {
        try {
          future.get();
        } catch (ExecutionException e) {
          e.printStackTrace();
        }
      }
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    threadPool.shutdownNow();
  }
}
