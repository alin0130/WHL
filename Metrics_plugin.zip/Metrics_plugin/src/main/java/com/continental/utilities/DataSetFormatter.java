package com.continental.utilities;
import java.text.SimpleDateFormat;
import java.util.Set;
import java.util.TreeSet;

import com.continental.MetricsPlugin.EMetricsModelType;
import com.continental.MetricsPlugin.MetricsModel;

import flexjson.JSONSerializer;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;

// TODO: Auto-generated Javadoc
/**
 * The Class DataSetFormatter.
 */
public class DataSetFormatter {

  /**
   * Gets the formated data set.
   *
   * @param metricsModel the metrics model
   * @param modelType the model type
   * @param categoryName the category name
   * @param index the index
   * @return the formated data set
   */
  public static String getFormatedDataSet(MetricsModel metricsModel, EMetricsModelType modelType, String categoryName, int index,AbstractProject<?, ?> project) {
    StringBuffer stringBuffer = new StringBuffer("['" + categoryName + "', ");
    Set<Integer> keySet =new TreeSet<Integer>(metricsModel.getMetricsSet(modelType).getIncluded().keySet());

    for (Integer key : keySet) {
    	if(isBuildAvailable(project, key)){
    		double[] ds = metricsModel.getMetricsSet(modelType).getIncluded().get(key);
    		stringBuffer.append(ds[index] + ", ");
    	}
    }
	stringBuffer.replace(stringBuffer.length() - 2, stringBuffer.length(), "]");
    
    return stringBuffer.toString();

  }

  private static boolean isBuildAvailable(AbstractProject<?, ?> project,int buildNumber){
	 AbstractBuild<?, ?> buildByNumber=project.getBuildByNumber(buildNumber);
	 if(buildByNumber==null){
		 return false;
	 }
	 return true;
  }
  
  /**
   * Gets the formated builds set.
   *
   * @param metricsModel the metrics model
   * @param modelType the model type
   * @param categoryName the category name
   * @param project the project
   * @return the formated builds set
   */
  public static String getFormatedBuildsSet(MetricsModel metricsModel, EMetricsModelType modelType,
		    String categoryName, AbstractProject<?, ?> project) {
			/*
			 * The dateFormat is the date format of the build tooltip in graphs
			 */
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		    StringBuffer sb = new StringBuffer("['" + categoryName + "', ");
		    Set<Integer> buildNumberSet=new TreeSet<Integer>(metricsModel.getMetricsSet(modelType).getIncluded().keySet());

		    JSONSerializer jsonSerializer = new JSONSerializer();
		    for (Integer buildNumber : buildNumberSet) {
		      AbstractBuild<?, ?> buildByNumber = project.getBuildByNumber(buildNumber);
		  
		      
		      if (buildByNumber != null) {
		    	String buildTimeStamp = dateFormat.format(buildByNumber.getTimestamp().getTime()); /* Get the build by number and then get the timestamp that is converted to dateFormat format */
		        sb.append("'");
		        sb.append(jsonSerializer.serialize(buildByNumber.getDisplayName() + " - " + buildTimeStamp));
		        sb.append("', ");
		      }
		   
		    }
		    sb.replace(sb.length() - 2, sb.length(), "]");
		    
		    return sb.toString();
		  }
}
