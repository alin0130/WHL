package com.continental.utilities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.tools.ant.Project;

import com.continental.MetricsPlugin.MetricsModel;

import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;
import hudson.model.Run;

public class MetricsUtilities {

	private static final String K4_JSON = "K4.json";
	private static final String K3_JSON = "K3.json";
	private static final String K3_AND_K4_FILE= "K3_K4_query_result.txt";
	

	public static EStatus saveMetricsToJSONData(File file, MetricsModel metricsModel) {

		try {
			JSONSerializer jsonSerializer = new JSONSerializer();
			String deepSerialize = jsonSerializer.deepSerialize(metricsModel);
			Files.write(file.toPath(), deepSerialize.getBytes(), StandardOpenOption.CREATE);
		} catch (IOException e) {
			e.printStackTrace();
			return EStatus.FAILURE;
		}
		return EStatus.SUCCESS;
	}

	public static MetricsModel loadMetricsFromJSONData(File fromFile) {
		/*
		 * We need to change the class loader because of different context of
		 * execution used my Jenkins (jelly/Java/etc).
		 */
		ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
		Thread.currentThread().setContextClassLoader(MetricsUtilities.class.getClassLoader());
		try {
			String fileContent = new String(Files.readAllBytes(fromFile.toPath()));
			JSONDeserializer<MetricsModel> jsonDeserializer = new JSONDeserializer<MetricsModel>();
			MetricsModel metricsModel = jsonDeserializer.deserialize(fileContent);
			return metricsModel;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			Thread.currentThread().setContextClassLoader(contextClassLoader);
		}
		return null;
	}

	public static File getK3AndK4Folder(Run<?, ?> build) {
		return new File(build.getRootDir(), GlobalProperties.METRICS_FOLDER);
	}

	public static File getK3AndK4File(Run<?, ?> build) {
		return new File(getK3AndK4Folder(build), K3_AND_K4_FILE);
	}
	
	public static File getEnvFile(Run<?, ?> build) {
		return new File(getK3AndK4Folder(build), "env.txt");
	}

	public static String substituteVariables(String template, Map<String, String> variables) {
		Pattern pattern = Pattern.compile("\\$\\{(.+?)\\}");
		Matcher matcher = pattern.matcher(template);

		StringBuffer buffer = new StringBuffer();
		while (matcher.find()) {
			if (variables.containsKey(matcher.group(1))) {
				String replacement = variables.get(matcher.group(1));
				
				// quote to work properly with $ and {,} signs
				matcher.appendReplacement(buffer, replacement != null ? Matcher.quoteReplacement(replacement) : "null");
			}
		}

		matcher.appendTail(buffer);
		return buffer.toString();
	}
	
	public static String substituteEnvVariables(String content,String env) {
		String envVar = content.substring(content.indexOf("=")+1);
		envVar = envVar.contains("comptab") ? envVar.replace("comptab", env) : envVar.concat("\\" + env);
		return envVar.trim();
	}

	public static File createK3K4DestinationFile(Run<?, ?> build) {
		return getK3AndK4File(build);
	}
	
	public static File createEnvDestinationFile(Run<?, ?> build) {
		return getEnvFile(build);
	}
	
	/**
	 * Replace a given line<lineNumber> in a given file<sourceFilePath>.
	 *
	 * @param sourceFilePath the source file path
	 * @param noPasswdCommand the no passwd command
	 */
	public static void replaceLine(File sourceFilePath,String noPasswdCommand,int lineNumber) {
		StringBuffer strBuff = new StringBuffer();
		try (BufferedReader jiraReader = new BufferedReader(new FileReader(sourceFilePath))){

			String currentLine;
			
			for (int i = 0; (currentLine = jiraReader.readLine())!=null; i++){
				if (i == lineNumber) {
					strBuff.append(noPasswdCommand);
					strBuff.append('\n');
				}
				else {
					strBuff.append(currentLine);
					strBuff.append('\n');
				}
			}
			
		}
		
		catch (IOException e) {
			e.printStackTrace();
		}
	
		
		try (BufferedWriter writer = new BufferedWriter (new OutputStreamWriter(new FileOutputStream(sourceFilePath)))){
			writer.write(strBuff.toString());
		}
		
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Optional<File> getK3JsonFile(Run<?, ?> build) {
		File k3AndK4Folder = getMetricsFolder(build);
		File K3JsonFile = new File(k3AndK4Folder, K3_JSON);
		if (!K3JsonFile.exists()) {
			return Optional.empty();
		}
		return Optional.of(K3JsonFile);
	}

	public static File createK3JSONFile(Run<?, ?> build) {
		File createMetricsFolder = createMetricsFolder(build);
		return new File(createMetricsFolder, K3_JSON);
	}

	public static File createK4JSONFile(Run<?, ?> build) {
		File createMetricsFolder = createMetricsFolder(build);
		return new File(createMetricsFolder, K4_JSON);
	}

	public static File getMetricsFolder(Run<?, ?> build) {
		return new File(build.getRootDir(), GlobalProperties.METRICS_FOLDER);
	}
	
	/**
	 * @param build 
	 * @return  -  KPI folder as a File object
	 */
	public static File getKPIFolder(Run<?, ?> build) {
		File buildPath = build.getRootDir().getParentFile().getParentFile();
		System.out.println(buildPath);
		return new File(buildPath, GlobalProperties.KPI_FOLDER);
	}


	public static File createMetricsFolder(Run<?, ?> build) {
		File destinationPath = getMetricsFolder(build);
		destinationPath.mkdirs();
		destinationPath.setWritable(true);
		return destinationPath;
	}
	
	/**
	 * @param build 
	 * @return KPI folder Path, but also creates "KPI" folder at the same lavel with "builds" folder
	 */
	public static File createKPIFolder(Run<?, ?> build) {
		File destinationPath = new File(build.getRootDir().getParentFile().getParentFile(),GlobalProperties.KPI_FOLDER);
		if (!destinationPath.exists()) {
			destinationPath.mkdirs();
			destinationPath.setWritable(true);
		}
		return destinationPath;
	}

	public static Optional<File> getK4JsonFile(Run<?, ?> build) {
		File k3AndK4Folder = getMetricsFolder(build);
		File K3JsonFile = new File(k3AndK4Folder, K4_JSON);
		if (!K3JsonFile.exists()) {
			return Optional.empty();
		}
		return Optional.of(K3JsonFile);
	}
	
	/**
	 * @param fileName
	 * @return an ArrayList- each element represents a line text
	 */
	public ArrayList<String> getValueFromTxtFile(File fileName) {
		ArrayList<String> fileValues = new ArrayList<String>();
		try (BufferedReader fileValue = new BufferedReader(new FileReader(fileName))){	
			String line = null;
			while ((line = fileValue.readLine()) != null) {
				fileValues.add(line);
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return fileValues;
	}
	
	/**
	 * @param fileValues
	 * @param lineNumer
	 * @return String  from @lineNumber 
	 */
	public String getTxtFileLineValue(ArrayList<String> fileValues, int lineNumer){
		String lineValue="";
		if(!fileValues.isEmpty()){
			lineValue=fileValues.get(lineNumer);
		}
		return lineValue;
	}
	
	public File createNewFile(File oldFile, String newFileName) {
		File pathFile = new File(oldFile, GlobalProperties.METRICS_FOLDER);
		File newFile = new File(pathFile, newFileName);
		return newFile;
	}
	
	/**
	 * @param source  - source file path
	 * @param destination - destination file path 
	 * @param fileName - file name of the file to be copied
	 * @return TRUE, if the file can be copied from source to destination(override the existing one), FALSE otherwise 
	 */
	public static boolean copyFile(String source, String destination, String fileName) {
		
		File f1 = new File(source, fileName);
		File f2 = new File(destination, fileName);
		boolean ok = true;
		try {
			Files.copy(f1.toPath(), f2.toPath(),StandardCopyOption.REPLACE_EXISTING);
			System.out.println("File copied to destination.");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			ok = false;
		}
		return ok;
	}
}
