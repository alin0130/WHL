/*
 * The Continental License
 * 
 * Copyright  2017(C) < S.C. Continental Automotive Romania S.R.L >
 * 
 * Created on    : Oct 10, 2014
 * Author        : uidw6888
 * 
 * Last revision : Oct 10, 2017 , 9:47:28 AM
 * Author        : uidt6436
 *
 * History from IMS Integrity Client:
 * 
 * $Log: ResultsSaver.java  $
 * Revision 1.13 2017/10/10 09:47:29CEST Oparlescu, Vlad (uidt6436) 
 * RO : 649524
 * 
 */
package com.continental.utilities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;
import java.nio.file.Paths;
import java.util.Map;

import hudson.EnvVars;
import hudson.FilePath;
import hudson.model.AbstractBuild;
import hudson.model.Computer;
import hudson.model.Run;

// TODO: Auto-generated Javadoc
/**
 * The Class ResultsSaver.
 */
public class ResultsSaver {

	/** The build. */
	private AbstractBuild<?, ?> build;
	
	/** The run build. */
	private Run<?,?> runBuild;

	/**
	 * Instantiates a new results saver.
	 *
	 * @param build the build
	 */
	public ResultsSaver(AbstractBuild<?, ?> build) {

		this.build = build;

	}
	
	/**
	 * Instantiates a new results saver.
	 *
	 * @param build the build
	 */
	public ResultsSaver(Run<?, ?> build) {
		this.runBuild = build;
	}

	/**
	 * Save file executor.
	 *
	 * @param sourcePath the source path
	 * @param logger the logger
	 * @return the e status
	 */
	public EStatus saveFileExecutor(String sourcePath, PrintStream logger) {

		FilePath source = new FilePath(Computer.currentComputer().getChannel(), sourcePath);
		File destinationPath = MetricsUtilities.createMetricsFolder(build);
		File  kpiFolder= MetricsUtilities.createKPIFolder(build);

		String name = Paths.get(sourcePath).getFileName().toString();
		FilePath destination = createNewDestination(destinationPath, name);
		try {

			EStatus e = (saveFile(source, destination, logger) == EStatus.SUCCESS) ? EStatus.SUCCESS : EStatus.FAILURE;
			return e;
		} catch (IOException | InterruptedException | NullPointerException e) {
			e.printStackTrace();
		}

		return EStatus.FAILURE;

	}

	/**
	 * Creates the new destination.
	 *
	 * @param destinationPath is a Path (D:\)
	 * @param fileName is the file name(ex. a.txt)
	 * @return a filePath (D:\a.txt)
	 */
	private FilePath createNewDestination(File destinationPath, String fileName) {
		File pathFile = new File(destinationPath, fileName);
		
		FilePath destination = new FilePath(pathFile.getAbsoluteFile());
		
		return destination;
	}
	
	// split the path by "/". return the last element of the path, which is the
	/**
	 * Gets the source file name.
	 *
	 * @param sourcePath the source path
	 * @return the source file name
	 */
	// SourceFileName
	public String getSourceFileName(String sourcePath) {
		String name = "";
		try {
			String[] sourcePathSplit = sourcePath.split("\\\\");
			int NrOfwords = sourcePathSplit.length;
			name = sourcePathSplit[NrOfwords - 1];
		} catch (Exception e) {}
		
		return name;
	}
	
	/**
	 * Creates the file.
	 *
	 * @param destinationPath the destination path
	 * @param fileName the file name
	 * @param value1  is the text written on the 1st line in the new file
	 * @param value2  is the text written on the 2nd line in the new file
	 * @return true, if successful
	 */
	public boolean createFile(File destinationPath, String fileName, String value1, String value2) {
		File file = new File(destinationPath, fileName);
		boolean result = true; 
		try {
			if (file.createNewFile()) {
				file.setWritable(true);
				//metricsLogs.consoleLogs(fileName + " is created!");
				//System.out.println(fileName + " is created!");
			} else {
				//metricsLogs.consoleLogs(fileName + " already exists.");
				//System.out.println(fileName + " already exists.");
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			result = false;
			e1.printStackTrace();
		}
		
		Writer writer = null;
		try {
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "utf-8"));
			writer.write(value1);
			writer.write(System.lineSeparator());
			writer.write(value2);
		} catch (IOException e) {
			result = false;
			//metricsLogs.consoleLogs("K1 - Can not create K1 file");
		}
		finally {
			try {
				writer.close();
			} catch (Exception ex) {/* ignore */
			}
		}
		return result;
	}
	
	/**
	 * Save file.
	 *
	 * @param sourceFile the source file
	 * @param destFile the dest file
	 * @param logger the logger
	 * @return the e status
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws InterruptedException the interrupted exception
	 */
	private EStatus saveFile(FilePath sourceFile, FilePath destFile, PrintStream logger)
			throws IOException, InterruptedException {

		logger.println("\nStart copying source file: " + sourceFile.getBaseName() + " to " + getJenkinsMasterName() + " Master PC...");

		if (!sourceFile.exists()) {

			logger.format("File %s doesn't exist...", sourceFile.getBaseName());

			return EStatus.FAILURE;

		}

		sourceFile.copyTo(destFile);
		logger.format("Done saving %s!", sourceFile.getBaseName());

		return EStatus.SUCCESS;

	}

	/**
	 * Gets the jenkins master name.
	 *
	 * @return the jenkins master name
	 */
	private String getJenkinsMasterName() {

		Run<?, ?> lastBuid = Computer.currentComputer().getBuilds().getLastBuild();

		try {

			EnvVars envVars = lastBuid.getEnvironment(null);

			Map<String, String> map = envVars.descendingMap();

			return map.get("COMPUTERNAME");

		} catch (IOException | InterruptedException e) {

			e.printStackTrace();
		}

		return "";

	}

}
