package com.continental.MetricsPlugin;

/**
 * Model class that represents a line in the </br>
 * </br>
 * %HUDSON_HOME%\jobs\[JOB_NAME]\builds\[build_number]\metrics\
 * K3_K4_query_result.txt
 * 
 * </br>
 * </br>
 * 
 * E.g. :
 * 
 * <p>
 * "ID",&emsp;&emsp;&emsp;"Project",&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&
 * emsp;"Detected by",&emsp;&emsp;"Caused by", </br>
 * </br>
 * "5680",&emsp;"/BS/ProcessMethodsTools",&emsp;"Internal Customer"
 * ,&emsp;"Design",&emsp; </br>
 * "5737",&emsp;"/BS/ProcessMethodsTools",&emsp;"Development",&emsp;"Solution",&
 * emsp; </br>
 * "5894",&emsp;"/BS/ProcessMethodsTools",&emsp;"Review",&emsp;"",&emsp;
 * </p>
 * 
 * @author uidu5465
 *
 */
public class K4Model {

	private String id = "";
	private String project = "";
	private String detectedBy = "";
	private CausedBy causedBy = CausedBy.UNSPECIFIED;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getDetectedBy() {
		return detectedBy;
	}

	public void setDetectedBy(String detectedBy) {
		this.detectedBy = detectedBy;
	}

	public CausedBy getCausedBy() {
		return causedBy;
	}

	public void setCausedBy(String causedBy) {
		this.causedBy = CausedBy.createCauseBy(causedBy);
	}

	@Override
	public String toString() {
		return String.format("K3Model [id=%s, project=%s, detectedBy=%s, causedBy=%s]", id, project, detectedBy, causedBy);
	}

}
