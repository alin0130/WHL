package com.continental.MetricsPlugin;

import com.google.common.base.Strings;

/**
 * CausedBy represents all possible caused by reason for an IMS ISSUE of type
 * problem report to exists:
 * 
 * <p>
 * <ol>
 * <li>requirement</li>
 * <li>architecture</li>
 * <li>design</li>
 * <li>solution</li>
 * <li>integration</li>
 * <li>test</li>
 * <li>calibration</li>
 * <li>unspecified</li>
 * <ol>
 * <p>
 * 
 * 
 * @author uidu5465
 *
 */
public enum CausedBy {
	REQUIREMENT("requirement"), ARCHITECTURE("architecture"), DESIGN("design"), SOLUTION("solution"), 
	INTEGRATION("integration"), TEST("test"), CALIBRATION("calibration"), UNSPECIFIED("unspecified");
	
	private String value = "unspecified";
	public static CausedBy createCauseBy(String value) {
		
		if (Strings.isNullOrEmpty(value)) {
			return UNSPECIFIED;
		}

		String localValue = value.toLowerCase();
		switch (localValue)
			{
				case "requirement":
					return REQUIREMENT;
				case "architecture":
					return ARCHITECTURE;
				case "design":
					return DESIGN;
				case "solution":
					return SOLUTION;
				case "integration":
					return INTEGRATION;
				case "test":
					return TEST;
				case "calibration":
					return CALIBRATION;
				default:
					return UNSPECIFIED;
			}
	}

	private CausedBy(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return value;
	}
}
