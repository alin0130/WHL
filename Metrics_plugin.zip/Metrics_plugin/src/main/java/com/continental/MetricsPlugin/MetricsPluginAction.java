/*
 * The Continental License
 * 
 * Copyright  2017(C) < S.C. Continental Automotive Romania S.R.L >
 * 
 * Created on    : Oct 10, 2014
 * Author        : uidu5465
 * 
 * Last revision : Sep 28, 2017 , 8:57:13 AM
 * Author        : uidt6436
 *
 * History from IMS Integrity Client:
 * 
 * $Log: MetricsPluginAction.java  $
 * Revision 1.31 2017/09/28 08:12:19CEST Oparlescu, Vlad (uidt6436) 
 * RO 576256 : K2, K3,K4, K5 available in the console
 * 
 */
package com.continental.MetricsPlugin;

import hudson.Extension;
import hudson.model.Action;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Job;
import hudson.model.Run;
import hudson.model.listeners.RunListener;

import java.io.File;
import java.io.PrintStream;

import net.sf.json.JSONObject;

import com.continental.utilities.DataSetFormatter;
import com.continental.utilities.GlobalProperties;
import com.continental.utilities.MetricsUtilities;
import com.continental.utilities.ProjectMetricsJobIterator;
import com.continental.utilities.socketio.SocketIOService;

// TODO: Auto-generated Javadoc
/**
 * The Class MetricsPluginAction.
 */
public class MetricsPluginAction implements Action {

	/** The project. */
	private AbstractProject<?, ?> project;

	/** The metrics model. */
	private MetricsModel metricsModel;

	/**
	 * Instantiates a new metrics plugin action.
	 */
	public MetricsPluginAction() {

		super();

	}
	
	/**
	 * Instantiates a new metrics plugin action.
	 *
	 * @param project the project
	 * @param metricsModel the metrics model
	 */
	public MetricsPluginAction(AbstractProject<?, ?> project, MetricsModel metricsModel) {
		this.project = project;
		if (metricsModel == null) {
			this.metricsModel = new MetricsModel();
			this.metricsModel.initializeModel();
			buildJSONFile();
		} else {
			this.metricsModel = metricsModel;
		}
	}

	/**
	 * The listener interface for receiving myRun events.
	 * The class that is interested in processing a myRun
	 * event implements this interface, and the object created
	 * with that class is registered with a component using the
	 * component's <code>addMyRunListener<code> method. When
	 * the myRun event occurs, that object's appropriate
	 * method is invoked.
	 *
	 * @see MyRunEvent
	 */
	@Extension
	public static final class MyRunListener extends RunListener<Run<?, ?>> {
		
		/* (non-Javadoc)
		 * @see hudson.model.listeners.RunListener#onFinalized(hudson.model.Run)
		 */
		@Override
		public void onFinalized(Run<?, ?> r) {
			MetricsPluginAction action = r.getParent().getAction(MetricsPluginAction.class);
			if (action == null) {
				return;
			}
			JSONObject json = new JSONObject().element("projectName", r.getParent().getName()).element("buildDisplayNumber", new Integer(r.getNumber())).element("buildStatus", r.getResult().toString());
		SocketIOService.send(json.toString());
		}

		/* (non-Javadoc)
		 * @see hudson.model.listeners.RunListener#onDeleted(hudson.model.Run)
		 */
		@Override
		public void onDeleted(Run<?, ?> r) {
			Job<?, ?> job = r.getParent();
			if (!shouldTreatJob(job)) {
				return;
			}

			/*
			 * build number that is to be deleted
			 */
			int number = r.getNumber();
			MetricsPluginAction action = job.getAction(MetricsPluginAction.class);
			MetricsModel metricsModel = action.getMetricsModel();

			metricsModel.deleteBuild(number);

			File file = new File(job.getRootDir(), GlobalProperties.RESULT_NAME);

			MetricsUtilities.saveMetricsToJSONData(file, metricsModel);

		}

		/**
		 * Should treat job.
		 *
		 * @param job the job
		 * @return true, if successful
		 */
		private boolean shouldTreatJob(Job<?, ?> job) {

			return (job.getAction(MetricsPluginAction.class) != null);
		}
	}

	/* (non-Javadoc)
	 * @see hudson.model.Action#getIconFileName()
	 */
	@Override
	public String getIconFileName() {
		//
		return GlobalProperties.PLUGIN_ICON;

	}

	/* (non-Javadoc)
	 * @see hudson.model.Action#getDisplayName()
	 */
	@Override
	public String getDisplayName() {
		return GlobalProperties.MISRA_LINK;
	}

	/* (non-Javadoc)
	 * @see hudson.model.Action#getUrlName()
	 */
	@Override
	public String getUrlName() {
		return GlobalProperties.PLUGIN_URL;
	}

	/**
	 * Gets the ram values metrics.
	 *
	 * @return the ram values metrics
	 */
	public String getRamValuesMetrics() {
		StringBuffer result = new StringBuffer("[");
		String BuildsRAMSet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.RAM, "BUILD", project);
		String avRAMSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.RAM, "Available RAM", 0,project);
		String moUsedRAMSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.RAM, "Used RAM/Memory Object", 1,project);
		result.append(BuildsRAMSet);
		result.append(",");
		result.append(avRAMSet);
		result.append(",");
		result.append(moUsedRAMSet);
		result.append("]");

		return result.toString();
	}

	/**
	 * Builds the JSON file.
	 */
	private void buildJSONFile() {
		MetricsModel metricsModel = new MetricsModel();
		metricsModel.initializeModel();

		ProjectMetricsJobIterator xmlParsers = new ProjectMetricsJobIterator(project, metricsModel, "MISRA");
		xmlParsers.iterateOnBuildsAndStartParser();

		File file = new File(project.getRootDir(), GlobalProperties.RESULT_NAME);

		MetricsUtilities.saveMetricsToJSONData(file, metricsModel);

		this.metricsModel = metricsModel;

	}

	/**
	 * Gets the rom metrics.
	 *
	 * @return the rom metrics
	 */
	public String getRomMetrics() {
		StringBuffer result = new StringBuffer("[");
		String BuildsROMSet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.ROM, "BUILD", project);
		String avROMSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.ROM, "Available ROM", 0,project);
		String moUsedROMSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.ROM, "Used ROM/Memory Object", 1,project);
		result.append(BuildsROMSet);
		result.append(",");
		result.append(avROMSet);
		result.append(",");
		result.append(moUsedROMSet);
		result.append("]");

		return result.toString();

	}
	 
	/**
	 * Gets the eeprom metrics.
	 *
	 * @return the eeprom metrics
	 */
	public String getEepromMetrics() {
		StringBuffer result = new StringBuffer("[");
		String BuildsEEPROMSet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.EEPROM, "BUILD", project);
		String avEEPROMSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.EEPROM, "Available EEPROM", 0,project);
		String moUsedEEPROMSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.EEPROM, "Used EEPROM/Memory Object", 1,project);
		result.append(BuildsEEPROMSet);
		result.append(",");
		result.append(avEEPROMSet);
		result.append(",");
		result.append(moUsedEEPROMSet);
		result.append("]");

		return result.toString();

	}

	/**
	 * Gets the deviations absolute metrics.
	 *
	 * @return the deviations absolute metrics
	 */
	public String getDeviationsAbsoluteMetrics() {
		StringBuffer result = new StringBuffer("[");
		String BuildsDeviationsAbsSet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.DEVIATONS_ABS, "BUILD", project);
		String subcontractedDeviationsAbsSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATONS_ABS, "subcontracted", 4,project);
		String thirdpartyDeviationsAbsSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATONS_ABS, "3rdparty", 5,project);
		String autogeneratedDeviationsAbsSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATONS_ABS, "autogenerated", 3,project);
		String unmodifiedreusedDeviationsAbsSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATONS_ABS, "unmodifiedreused", 0,project);
		String modifiedreusedDeviationsAbsSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATONS_ABS, "modifiedreused", 1,project);
		String newcodeDeviationsAbsSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATONS_ABS, "newcode", 2,project);
		result.append(BuildsDeviationsAbsSet);
		result.append(",");
		result.append(unmodifiedreusedDeviationsAbsSet);
		result.append(",");
		result.append(modifiedreusedDeviationsAbsSet);
		result.append(",");
		result.append(autogeneratedDeviationsAbsSet);
		result.append(",");
		result.append(newcodeDeviationsAbsSet);
		result.append(",");
		result.append(subcontractedDeviationsAbsSet);
		result.append(",");
		result.append(thirdpartyDeviationsAbsSet);
		result.append("]");

		return result.toString();

	}

	/**
	 * Gets the deviations per eloc metrics.
	 *
	 * @return the deviations per eloc metrics
	 */
	public String getDeviationsPerElocMetrics() {
		StringBuffer result = new StringBuffer("[");
		String BuildsDeviationsElocSet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.DEVIATIONS_ELOC, "BUILD", project);
		String subcontractedDeviationsElocSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATIONS_ELOC, "subcontracted", 0,project);
		String thirdpartyDeviationsElocSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATIONS_ELOC, "3rdparty", 1,project);
		String autogeneratedDeviationsElocSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATIONS_ELOC, "autogenerated", 2,project);
		String unmodifiedreusedDeviationsElocSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATIONS_ELOC, "unmodifiedreused", 3,project);
		String modifiedreusedDeviationsElocSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATIONS_ELOC, "modifiedreused", 4,project);
		String newcodeDeviationsElocSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.DEVIATIONS_ELOC, "newcode", 5,project);
		result.append(BuildsDeviationsElocSet);
		result.append(",");
		result.append(subcontractedDeviationsElocSet);
		result.append(",");
		result.append(thirdpartyDeviationsElocSet);
		result.append(",");
		result.append(autogeneratedDeviationsElocSet);
		result.append(",");
		result.append(unmodifiedreusedDeviationsElocSet);
		result.append(",");
		result.append(modifiedreusedDeviationsElocSet);
		result.append(",");
		result.append(newcodeDeviationsElocSet);
		result.append("]");

		return result.toString();

	}

	/**
	 * Gets the builds the warnings metrics.
	 *
	 * @return the builds the warnings metrics
	 */
	public String getBuildWarningsMetrics() {

		StringBuffer result = new StringBuffer("[");
		String BuildsBuildWarningsMSet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.BUILD_WARNINGS, "BUILD", project);
		String buildWarningsSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.BUILD_WARNINGS, "Build Warnings", 0,project);
		result.append(BuildsBuildWarningsMSet);
		result.append(",");
		result.append(buildWarningsSet);
		result.append("]");

		return result.toString();

	}

	/**
	 * Gets the linker warnings metrics.
	 *
	 * @return the linker warnings metrics
	 */
	public String getLinkerWarningsMetrics() {

		StringBuffer result = new StringBuffer("[");
		String BuildsLinkerWarningsMSet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.LINKER_WARNINGS, "BUILD", project);
		String linkerWarningsSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.LINKER_WARNINGS, "Linker Warnings", 0,project);
		result.append(BuildsLinkerWarningsMSet);
		result.append(",");
		result.append(linkerWarningsSet);
		result.append("]");

		return result.toString();

	}

	/**
	 * Gets the project eloc metrics.
	 *
	 * @return the project eloc metrics
	 */
	public String getProjectElocMetrics() {

		StringBuffer result = new StringBuffer("[");
		String BuildsProjectElocSet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.ELOC_CODE, "BUILD", project);

		String elocNonSafetySet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.ELOC_CODE, "ELOC of non-safety code", 0,project);

		String elocSafetySet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.ELOC_CODE, "ELOC of safety code", 1,project);

		result.append(BuildsProjectElocSet);
		result.append(",");
		result.append(elocNonSafetySet);
		result.append(",");
		result.append(elocSafetySet);
		result.append("]");

		return result.toString();

	}

	/**
	 * Gets the cyclo complexity metrics.
	 *
	 * @return the cyclo complexity metrics
	 */
	public String getCycloComplexityMetrics() {
		StringBuffer result = new StringBuffer("[");
		String buildsCycloComplexitySet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.CYCLO_COMPLEX, "BUILD", project);
		String betweenCycloComplexitySet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.CYCLO_COMPLEX, "between 15 and 30", 0,project);
		String higherCycloComplexitySet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.CYCLO_COMPLEX, "higher than 30", 1,project);

		result.append(buildsCycloComplexitySet);
		result.append(",");
		result.append(betweenCycloComplexitySet);
		result.append(",");
		result.append(higherCycloComplexitySet);
		result.append("]");

		return result.toString();
	}

	/**
	 * Gets the misra advisory recommended metrics.
	 *
	 * @return the misra advisory recommended metrics
	 */
	public String getMisraAdvisoryRecommendedMetrics() {
		StringBuffer result = new StringBuffer("[");
		String BuildsMisraAdvisorySet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.MISRA_ADVISORY, "BUILD", project);
		String subcontractedMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_ADVISORY, "subcontracted", 0,project);
		String thirdpartyMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_ADVISORY, "3rdparty", 1,project);
		String autogeneratedMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_ADVISORY, "autogenerated", 2,project);
		String unmodifiedreusedMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_ADVISORY, "unmodifiedreused", 3,project);
		String modifiedreusedMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_ADVISORY, "modifiedreused", 4,project);
		String newcodeMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_ADVISORY, "newcode", 5,project);
		result.append(BuildsMisraAdvisorySet);
		result.append(",");
		result.append(subcontractedMisraSet);
		result.append(",");
		result.append(thirdpartyMisraSet);
		result.append(",");
		result.append(autogeneratedMisraSet);
		result.append(",");
		result.append(unmodifiedreusedMisraSet);
		result.append(",");
		result.append(modifiedreusedMisraSet);
		result.append(",");
		result.append(newcodeMisraSet);
		result.append("]");

		return result.toString();
	}

	/**
	 * Gets the misra required obligatory metrics.
	 *
	 * @return the misra required obligatory metrics
	 */
	public String getMisraRequiredObligatoryMetrics() {

		StringBuffer result = new StringBuffer("[");
		String BuildsMisraRequiredSet = DataSetFormatter.getFormatedBuildsSet(metricsModel, EMetricsModelType.MISRA_REQ, "BUILD", project);
		String subcontractedMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_REQ, "subcontracted", 0,project);
		String thirdpartyMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_REQ, "3rdparty", 1,project);
		String autogeneratedMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_REQ, "autogenerated", 2,project);
		String unmodifiedreusedMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_REQ, "unmodifiedreused", 3,project);
		String modifiedreusedMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_REQ, "modifiedreused", 4,project);
		String newcodeMisraSet = DataSetFormatter.getFormatedDataSet(metricsModel, EMetricsModelType.MISRA_REQ, "newcode", 5,project);
		result.append(BuildsMisraRequiredSet);
		result.append(",");
		result.append(subcontractedMisraSet);
		result.append(",");
		result.append(thirdpartyMisraSet);
		result.append(",");
		result.append(autogeneratedMisraSet);
		result.append(",");
		result.append(unmodifiedreusedMisraSet);
		result.append(",");
		result.append(modifiedreusedMisraSet);
		result.append(",");
		result.append(newcodeMisraSet);
		result.append("]");

		return result.toString();

	}

	/**
	 * Load.
	 *
	 * @param build the build
	 * @param logger the logger
	 */
	public void load(AbstractBuild<?, ?> build,PrintStream logger) {

		ProjectMetricsJobIterator projectMetricsJob = new ProjectMetricsJobIterator(build, metricsModel, "MISRA");
		projectMetricsJob.addBuildToModel(logger);

		File file = new File(build.getProject().getRootDir(), GlobalProperties.RESULT_NAME);

		MetricsUtilities.saveMetricsToJSONData(file, metricsModel);

	}

	/**
	 * Gets the metrics model.
	 *
	 * @return the metrics model
	 */
	public MetricsModel getMetricsModel() {

		return metricsModel;

	}

	/**
	 * Gets the project.
	 *
	 * @return the project
	 */
	public AbstractProject<?, ?> getProject() {
		return project;
	}

}
