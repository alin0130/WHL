/*
 * The Continental License
 * 
 * Copyright  2017(C) < S.C. Continental Automotive Romania S.R.L >
 * 
 * Created on    : Oct 10, 2014
 * Author        : uidu5465
 * 
 * Last revision : Sep 28, 2017 , 8:56:19 AM
 * Author        : uidt6436
 *
 * History from IMS Integrity Client:
 * 
 * $Log: KMetricsAction.java  $
 * Revision 1.15 2017/09/28 08:12:19CEST Oparlescu, Vlad (uidt6436) 
 * RO 576256 : K2, K3,K4, K5 available in the console
 * 
 */
package com.continental.MetricsPlugin;

import static com.continental.MetricsPlugin.EMetricsModelType.K2;
import static com.continental.MetricsPlugin.EMetricsModelType.K3;
import static com.continental.MetricsPlugin.EMetricsModelType.K4;
import static com.continental.MetricsPlugin.EMetricsModelType.K5;
import hudson.Extension;
import hudson.model.Action;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Job;
import hudson.model.Run;
import hudson.model.listeners.RunListener;

import java.io.File;
import java.io.PrintStream;

import net.sf.json.JSONObject;

import com.continental.utilities.DataSetFormatter;
import com.continental.utilities.GlobalProperties;
import com.continental.utilities.MetricsUtilities;
import com.continental.utilities.ProjectMetricsJobIterator;
import com.continental.utilities.socketio.SocketIOService;

// TODO: Auto-generated Javadoc
/**
 * The Class KMetricsAction.
 *
 * @author uidt6436
 */
public class KMetricsAction implements Action {

	/** The project. */
	private AbstractProject<?, ?> project;

	/** The metrics model. */
	private MetricsModel metricsModel;

	/**
	 * Instantiates a new k metrics action.
	 *
	 * @param project the project
	 * @param metricsModel the metrics model
	 */
	public KMetricsAction(AbstractProject<?, ?> project, MetricsModel metricsModel) {
		this.project = project;
		if (metricsModel == null) {
			this.metricsModel = new MetricsModel();
			this.metricsModel.initializeModel();
			buildJSONFile();
		} else {
			this.metricsModel = metricsModel;
		}
	}

	/**
	 * The listener interface for receiving myRun events.
	 * The class that is interested in processing a myRun
	 * event implements this interface, and the object created
	 * with that class is registered with a component using the
	 * component's <code>addMyRunListener<code> method. When
	 * the myRun event occurs, that object's appropriate
	 * method is invoked.
	 *
	 * @see MyRunEvent
	 */
	@Extension
	public static final class MyRunListener extends RunListener<Run<?, ?>> {	

		/* (non-Javadoc)
		 * @see hudson.model.listeners.RunListener#onFinalized(hudson.model.Run)
		 */
		@Override
		public void onFinalized(Run<?, ?> r) {
			KMetricsAction action = r.getParent().getAction(KMetricsAction.class);
			if (action == null) {
				return;
			}
			JSONObject json = new JSONObject().element("projectName", r.getParent().getName())
								.element("buildDisplayNumber", new Integer(r.getNumber()))
								.element("buildStatus", r.getResult().toString());
			SocketIOService.send(json.toString());
		}

		/* (non-Javadoc)
		 * @see hudson.model.listeners.RunListener#onDeleted(hudson.model.Run)
		 */
		@Override
		public void onDeleted(Run<?, ?> r) {
			Job<?, ?> job = r.getParent();
			if (!shouldTreatJob(job)) {
				return;
			}

			/*
			 * build number that is to be deleted
			 */
			int number = r.getNumber();
			
			KMetricsAction action = job.getAction(KMetricsAction.class);
			MetricsModel metricsModel = action.getMetricsModel();
			metricsModel.deleteBuild(number);
			File file = new File(job.getRootDir(), GlobalProperties.RESULT_NAME);
			MetricsUtilities.saveMetricsToJSONData(file, metricsModel);

		}

		/**
		 * Should treat job.
		 *
		 * @param job the job
		 * @return true, if successful
		 */
		private boolean shouldTreatJob(Job<?, ?> job) {
			return (job.getAction(KMetricsAction.class) != null);
		}
	}

	/* (non-Javadoc)
	 * @see hudson.model.Action#getIconFileName()
	 */
	@Override
	public String getIconFileName() {
		//
		return GlobalProperties.PLUGIN_ICON_K;

	}

	/* (non-Javadoc)
	 * @see hudson.model.Action#getDisplayName()
	 */
	@Override
	public String getDisplayName() {

		return GlobalProperties.K_LINK_NAME;
	}

	/* (non-Javadoc)
	 * @see hudson.model.Action#getUrlName()
	 */
	@Override
	public String getUrlName() {

		return GlobalProperties.PLUGIN_URL_K;

	}

	/**
	 * Builds the json file.
	 */
	private void buildJSONFile() {

		MetricsModel metricsModel = new MetricsModel();
		metricsModel.initializeModel();

		ProjectMetricsJobIterator xmlParsers = new ProjectMetricsJobIterator(project, metricsModel, "KPIS");
		xmlParsers.iterateOnBuildsAndStartParser();
		File file = new File(project.getRootDir(), GlobalProperties.RESULT_NAME);
		MetricsUtilities.saveMetricsToJSONData(file, metricsModel);

		this.metricsModel = metricsModel;

	}

	
	/**
	 * Gets the k2 metrics.
	 *
	 * @return the k2 metrics
	 */
	public String getK2Metrics() {
		StringBuffer result = new StringBuffer("[");
		String buildsK2Set = DataSetFormatter.getFormatedBuildsSet(metricsModel, K2, "BUILD", project);
		String elocTotal = DataSetFormatter.getFormatedDataSet(metricsModel, K2, "K2", 0,project);

		result.append(buildsK2Set);
		result.append(",");
		result.append(elocTotal);
		result.append("]");

		return result.toString();
	}

	/**
	 * Gets the k3 metrics.
	 *
	 * @return the k3 metrics
	 */
	public String getK3Metrics() {
		StringBuffer result = new StringBuffer("[");
		String buildsK3Set = DataSetFormatter.getFormatedBuildsSet(metricsModel, K3, "BUILD", project);
		String architecture = DataSetFormatter.getFormatedDataSet(metricsModel, K3, "Architecture", 0,project);
		String calibration = DataSetFormatter.getFormatedDataSet(metricsModel, K3, "Calibration", 1,project);
		String design = DataSetFormatter.getFormatedDataSet(metricsModel, K3, "Design", 2,project);
		String integration = DataSetFormatter.getFormatedDataSet(metricsModel, K3, "Integration", 3,project);
		String requirement = DataSetFormatter.getFormatedDataSet(metricsModel, K3, "Requirement", 4,project);
		String solution = DataSetFormatter.getFormatedDataSet(metricsModel, K3, "Solution", 5,project);
		String test = DataSetFormatter.getFormatedDataSet(metricsModel, K3, "Test", 6,project);
		String unspecified = DataSetFormatter.getFormatedDataSet(metricsModel, K3, "Unspecified", 7,project);

		result.append(buildsK3Set);
		result.append(",");
		result.append(architecture);
		result.append(",");
		result.append(calibration);
		result.append(",");
		result.append(design);
		result.append(",");
		result.append(integration);
		result.append(",");
		result.append(requirement);
		result.append(",");
		result.append(solution);
		result.append(",");
		result.append(test);
		result.append(",");
		result.append(unspecified);
		result.append("]");

		return result.toString();

	}

	/**
	 * Gets the k4 metrics.
	 *
	 * @return the k4 metrics
	 */
	public String getK4Metrics() {
		StringBuffer result = new StringBuffer("[");
		String buildsK4Set = DataSetFormatter.getFormatedBuildsSet(metricsModel, K4, "BUILD", project);
		String elocTotal = DataSetFormatter.getFormatedDataSet(metricsModel, K4, "Customer Defect Density", 0,project);

		result.append(buildsK4Set);
		result.append(",");
		result.append(elocTotal);
		result.append("]");

		return result.toString();

	}
	
	
	
	/**
	 * Gets the k5 metrics.
	 *
	 * @return the k5 metrics
	 */
	public String getK5Metrics() {
		StringBuffer result = new StringBuffer("[");
		String buildsK5Set = DataSetFormatter.getFormatedBuildsSet(metricsModel, K5, "BUILD", project);
		String elocTotal = DataSetFormatter.getFormatedDataSet(metricsModel, K5, "Software Requirements", 0,project);

		result.append(buildsK5Set);
		result.append(",");
		result.append(elocTotal);
		result.append("]");

		return result.toString();

	}

	/**
	 * Load.
	 *
	 * @param build the build
	 * Initialize the ProjectMetricsJobIterator with KPIS option (start threads for KPIs only)
	 */
	public void load(AbstractBuild<?, ?> build,PrintStream logger) {
		ProjectMetricsJobIterator projectMetricsJob = new ProjectMetricsJobIterator(build, metricsModel, "KPIS");

		projectMetricsJob.addBuildToModel(logger);
		File file = new File(build.getProject().getRootDir(), GlobalProperties.RESULT_NAME);
		MetricsUtilities.saveMetricsToJSONData(file, metricsModel);

	}

	/**
	 * Gets the metrics model.
	 *
	 * @return the metrics model
	 */
	public MetricsModel getMetricsModel() {
		return metricsModel;
	}

	/**
	 * Gets the project.
	 *
	 * @return the project
	 */
	public AbstractProject<?, ?> getProject() {

		return project;

	}

}
