/*
 * 
 */
package com.continental.MetricsPlugin;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.nio.file.Paths;

import javax.servlet.ServletException;

import org.jenkinsci.remoting.RoleChecker;
import org.kohsuke.stapler.AncestorInPath;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;
import org.kohsuke.stapler.StaplerRequest;

import com.continental.utilities.EStatus;
import com.continental.utilities.GlobalProperties;
import com.continental.utilities.MetricsUtilities;
import com.continental.utilities.ResultsSaver;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import hudson.Extension;
import hudson.EnvVars;
import hudson.FilePath;
import hudson.Launcher;
import hudson.PluginWrapper;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Action;
import hudson.model.AutoCompletionCandidates;
import hudson.model.BuildListener;
import hudson.model.Item;
import hudson.model.Label;
import hudson.model.Node;
import hudson.model.TaskListener;
import hudson.remoting.Callable;
import hudson.tasks.BatchFile;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.Publisher;
import hudson.tasks.Recorder;
import hudson.util.FormValidation;
import hudson.util.LineEndingConversion;
import jenkins.model.Jenkins;
import net.sf.json.JSONObject;

import javax.xml.bind.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class MetricsPluginPublisher.
 */
public class MetricsPluginPublisher extends Recorder {
	
	/** The Constant K3_AND_K4_FILE. */
	private static final String K3_AND_K4_FILE = "K3_K4_query_result.txt";
	
	/** The Constant CHECK_QUERY_K3_AND_K4_FILE. */
	private static final String CHECK_QUERY_K3_AND_K4_FILE = "CHECK_QUERY_K3_AND_K4_FILE";
	
	/** The Constant CHECK_PROJECT_K3_AND_K4_FILE. */
	private static final String CHECK_PROJECT_K3_AND_K4_FILE = "CHECK_PROJECT_K3_AND_K4_FILE";
	
    /** The k5 reports location. */
    private static String K5_REPORTS_LOCATION= "\\\\cw01.contiwan.com\\Root\\Loc\\rbgs\\did02215\\Doors_DATA\\IBS_Project_Metrics\\1_PMT_Automated\\KPI\\";
	
	/** The Constant NEW_LINE. */
	private static final String NEW_LINE = String.format("%n");
	
	/** The Constants DEFAULT_COMMAND. */
	private  static final String IMS_DEFAULT_COMMAND = "im createquery --fields=\"ID\" --queryDefinition='((field[Issue Type]=\"Problem Report\") and (not((field[State]=\"On hold\"))) and (not((field[State]=\"Canceled\"))) and (not((field[State]=\"Duplicate\"))) and (field[Project]=\"${projectName}\"))' --name=\"All PR for ${projectName}\""
												+ NEW_LINE + "im runreport --query=\"All PR for ${projectName}\" \"All PRs for KPI3 and KPI4\"" + NEW_LINE;

	/** The Constant JIRA_DEFAULT_COMMAND. */
	private static final String JIRA_DEFAULT_COMMAND = "${jiraUrl} ${userId} ${passwdKey} project%%20=%%20${projectName}%%20AND%%20issuetype%%20=%%20'Problem%%20Report%%20(PR)'";
	
	/** The Constants RUN_REPORT_COMMAND. */
	private static final String IMS_RUN_REPORT_COMMAND = "im runreport --query=\"All PR for ${projectName}\" \"All PRs for KPI3 and KPI4\"" + NEW_LINE;
	
	
	/** The Constant JIRA_RUN_REPORT_COMMAND. */
	private static final String JIRA_RUN_REPORT_COMMAND = "${jiraUrl} ${userId} ${passwdKey} project%%20=%%20${projectName}%%20AND%%20issuetype%%20=%%20'Problem%%20Report%%20(PR)'%%20AND%%20status%%20not%%20in%%20(Canceled,Duplicate)";
														

	/** The metrics result path. */
	private final String metricsResultPath;
	
	/** The doors project file. */
	private final String doorsProjectFile;
	
	/** The doors project file name. */
	private final String doorsProjectFileName;
	
	/** The ims project name. */
	private final String projectName;
	
	/** The edit command. */
	private final EditImsCommand editImsCommand;
	
	/** The edit command. */
	private final EditJiraCommand editJiraCommand;
	
	/** The tool version (IMS / JIRA). */
	private String versionTool;
	
	/** The user ID. */
	private final String userId;
	
	/** The JIRA URL. */
	private final String jiraUrl;
	
	/**  The user password. */
	private final String passwdKey;
	
	/** The logger. */
	public PrintStream logger;
	
	/** The log. */
	public TaskListener log;
	

	 /**
 	 * Gets the version tool.
 	 *
 	 * @return the version tool
 	 */
 	public String getVersionTool() {
         return versionTool;
     }
	
	 
	 /**
 	 * Gets the user id.
 	 *
 	 * @return the user id
 	 */
 	public String getUserId() {
         return userId;
     }
 	
 	/**
	  * Gets the jira url.
	  *
	  * @return the jira url
	  */
	 public String getJiraUrl() {
        return jiraUrl;
    }
	 
	 /**
 	 * Gets the secret key.
 	 *
 	 * @return the secret key
 	 */
 	public String getPasswdKey() {
         return passwdKey;
     }
 	
 	/**
	  * Gets the project name.
	  *
	  * @return the project name
	  */
	 public String getProjectName() {
		return projectName;
	}
	
	/**
	 * Instantiates a new metrics plugin publisher.
	 *
	 * @param metricsResultPath the metrics result path
	 * @param editImsCommand the edit ims command
	 * @param editJiraCommand the edit jira command
	 * @param versionTool the version tool
	 * @param projectName the project name
	 * @param doorsProjectFile the doors project file
	 * @param userId the user id
	 * @param passwdKey the password of the user
	 * @param jiraUrl the jira url
	 */
	@DataBoundConstructor
	public MetricsPluginPublisher(String metricsResultPath, EditImsCommand editImsCommand, EditJiraCommand editJiraCommand, String versionTool, String projectName,  String doorsProjectFile, String userId, String passwdKey, String jiraUrl) {
		this.metricsResultPath = metricsResultPath;
		this.projectName = projectName;
		this.editImsCommand = editImsCommand;
	
		this.editJiraCommand = editJiraCommand;
		this.versionTool = versionTool;
		this.doorsProjectFile=K5_REPORTS_LOCATION + doorsProjectFile;
		this.doorsProjectFileName=doorsProjectFile;
		this.userId = userId;
		this.passwdKey = passwdKey;
		this.jiraUrl = jiraUrl;
	}
	

	/* (non-Javadoc)
	 * @see hudson.tasks.BuildStepCompatibilityLayer#getProjectActions(hudson.model.AbstractProject)
	 */
	public Collection<? extends Action> getProjectActions(AbstractProject<?, ?> project) {
		List<Action> metrics = Lists.newArrayList();
		File fromFile = new File(project.getRootDir(), GlobalProperties.RESULT_NAME);
		if (fromFile.exists()) {
			MetricsModel loadMetricsFromJSONData = MetricsUtilities.loadMetricsFromJSONData(fromFile);
			/*
			 * k2 was added after the json file is created. we have to check if
			 * this metrics already exists in result.json file before the model
			 * is initialized
			 */
			if (null != loadMetricsFromJSONData.getMetricsSet(EMetricsModelType.K2)) {
				metrics.add(new KMetricsAction(project, loadMetricsFromJSONData));
			} else {
				metrics.add(new KMetricsAction(project, null));
			}
			metrics.add(new MetricsPluginAction(project, loadMetricsFromJSONData));
		} else {
			metrics.add(new MetricsPluginAction(project, null));
			metrics.add(new KMetricsAction(project, null));
		}
		
		return metrics;
	}
	
	/**
	 * Gets the environment of the job configuration.
	 *
	 * @param build            the build of the job
	 * @param key the key
	 * @param listener the listener
	 * @return the map that contains environmental variables to be used for
	 *         launching processes for this build.
	 */
	public String getEnv(AbstractBuild<?, ?> build, Object key, BuildListener listener) {

		String envVar = null;

		logger = listener.getLogger();
		try {
			envVar = key.toString().substring(1, key.toString().indexOf("%", 1));
		}

		catch (StringIndexOutOfBoundsException e) {
			logger.println("\nThe introduced file path of Metrics Result is not correct!");
			return null;
		}

		TaskListener log = null;

		EnvVars jobEnv = null;

		try {
			jobEnv = build.getEnvironment(log);
		}

		catch (IOException | InterruptedException e) {
			e.getStackTrace();
			logger.println("The job configuration environment could not be retrieved!");
			return null;
		}

		return jobEnv.get(envVar);
	}

	/* (non-Javadoc)
	 * @see hudson.tasks.BuildStepCompatibilityLayer#perform(hudson.model.AbstractBuild, hudson.Launcher, hudson.model.BuildListener)
	 */
	@Override
	public boolean perform(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener) {
		ResultsSaver saver = new ResultsSaver(build);
		PrintStream logger = listener.getLogger();
		PluginWrapper whichPlugin = Jenkins.getInstance().getPluginManager().whichPlugin(MetricsPluginPublisher.class);
		logger.println("Build started with " + whichPlugin.getDisplayName() + "\t version " + whichPlugin.getVersion());
		GlobalProperties.DOORS_FILE = saver.getSourceFileName(doorsProjectFile);
		
		if (metricsResultPath.length() > 0) {

			File configProjectMetrics = new File(metricsResultPath);

			if (configProjectMetrics.isAbsolute()) {
				
				GlobalProperties.PMPath = configProjectMetrics.getPath();
				if (saver.saveFileExecutor(GlobalProperties.PMPath, logger) == EStatus.FAILURE) {
					return false;
				}
			}
			
			else {
				String env = getEnv(build, metricsResultPath, listener);

				if (env != null) {
					env += configProjectMetrics.getPath().substring(configProjectMetrics.getPath().indexOf("%", 1) + 1);
				} else {
					logger.println("\nThe introduced file path of Metrics Result is not correct!");
					return false;
				}

				GlobalProperties.PMPath = env;
				if (saver.saveFileExecutor(GlobalProperties.PMPath, logger) == EStatus.FAILURE) {
					return false;
				}
			}
		}
		
		else {
			logger.println("\nMetricsPlugin - projectMetrics.xml file is not provided! Build will be set on FAILURE!");
			return false;
		}
		
		if (!("KPI".equals(GlobalProperties.DOORS_FILE) || "".equals(GlobalProperties.DOORS_FILE))) {
			if (saver.saveFileExecutor(doorsProjectFile, logger) == EStatus.FAILURE) {
				return false;
			}
		}
		
		/*
		* If imsProjectName is empty, do not execute the commands for K3, K4 report (IMS commands)
		*/
		if(projectName!=null && !projectName.isEmpty()) {
			executeComands(build, launcher, listener);
		} else {
			logger.println(System.getProperty("line.separator") + "IMS project name is empty. Skipping K3 and K4 report...");
		}
		
		MetricsPluginAction action = build.getProject().getAction(MetricsPluginAction.class);
		KMetricsAction action2 = build.getProject().getAction(KMetricsAction.class);

		try {
			action2.load(build,logger);
		} catch (Exception e) {
		}
		action.load(build,logger);
		
		return true;

	}

	/**
	 * Execute commands.
	 * This method is used to run the IMS and JIRA K3, K4 report. 
	 * First step is checking if an query already exists, if it exists the query is executed. Otherwise the batch will create a new query and then execute it.
	 *
	 * @param build the build
	 * @param launcher the launcher
	 * @param listener the listener
	 * @return true, if successful
	 */
	private boolean executeComands(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener) {
		try {
			
			FilePath sourcefileEnv = build.getWorkspace().child("env.txt");
			File sourceFileEnv = new File(sourcefileEnv.toURI());
			
			
			new MyBatchFile("set ts_ctl", sourceFileEnv).perform(build, launcher, listener);
			
			File destinationEnv = MetricsUtilities.getEnvFile(build);
			sourcefileEnv.copyTo(new FilePath(destinationEnv));
			
			String line2 = Files.readAllLines(Paths.get(destinationEnv.toURI())).get(2);
			sourcefileEnv.delete();
			
			String envVar = "java -jar" + " " + MetricsUtilities.substituteEnvVariables(line2,"jira_exporter\\JiraApi.jar");
			
			String realCommand;
			String noPasswdCommand="";
			
			
			PrintStream logger = listener.getLogger();
			Map<String, String> map = Maps.newHashMapWithExpectedSize(1);
			
			FilePath sourcefileIssueToolQuery = build.getWorkspace().child(CHECK_QUERY_K3_AND_K4_FILE);
			File fileIssueToolQuery = new File(sourcefileIssueToolQuery.toURI());
			
			boolean executionResultIssueToolQuery;
			
			/*
			 * First, check if the query is a valid one and the project is found.
			 * If Query exists execute it, otherwise create it and execute it
			 */
			
			if ("ims".equals(versionTool))
			{
				map.put("projectName", projectName);
				logger.println(System.getProperty("line.separator") + "Check if IMS query is valid: " + "im queries \"All PR for " + projectName + "\"");
				executionResultIssueToolQuery = new MyBatchFile("im queries \"All PR for " + projectName + "\"", fileIssueToolQuery).perform(build, launcher, listener);
				
				sourcefileIssueToolQuery.delete();
				
				logger.println("IMS Query Exists: " + executionResultIssueToolQuery);
				
				realCommand = MetricsUtilities.substituteVariables(getCommandToBeExecuted(executionResultIssueToolQuery,"IMS",null), map);
				logger.println("Real command executed is: " + realCommand);
			}
			
			
			else
			{
				map.put("projectName", projectName);
				map.put("userId", userId);
				map.put("jiraUrl", jiraUrl);
				
				logger.println(System.getProperty("line.separator") + "Check if JIRA query is valid: " + "project = " + projectName + " AND issuetype = 'Problem Report (PR)'");
				
				executionResultIssueToolQuery = new MyBatchFile(envVar + " " + jiraUrl + " " + userId + " " + passwdKey + " " + "project%%20=%%20" + projectName + "%%20AND%%20issuetype%%20=%%20'Problem%%20Report%%20(PR)'", fileIssueToolQuery).perform(build, launcher, listener);
				
				sourcefileIssueToolQuery.delete();
				
				logger.println("JIRA Query Exists: " + executionResultIssueToolQuery);
				realCommand = noPasswdCommand = MetricsUtilities.substituteVariables(getCommandToBeExecuted(executionResultIssueToolQuery,"JIRA",envVar), map);
				logger.println("Real command executed is: " + noPasswdCommand.replaceAll("%%20", " "));
				
			}
			
			FilePath sourcefilePath = build.getWorkspace().child(K3_AND_K4_FILE);
			File sourceFilePath = new File(sourcefilePath.toURI());
			
			boolean executionResult;
			
			if ("ims".equals(versionTool)) {
				executionResult = new MyBatchFile(realCommand, sourceFilePath).perform(build, launcher, listener);	
			}
			
			else{
				map.put("passwdKey", passwdKey);
				realCommand = MetricsUtilities.substituteVariables(getCommandToBeExecuted(executionResultIssueToolQuery,"JIRA",envVar), map);
				executionResult = new MyBatchFile(realCommand, sourceFilePath).perform(build, launcher, listener);
			}
			
			logger.println("Execution result is: " + executionResult);
			File destinationPath = MetricsUtilities.createK3K4DestinationFile(build) ;
			sourcefilePath.copyTo(new FilePath(destinationPath));
			sourcefilePath.delete();
			
			if ("jira".equals(versionTool))
			{
				MetricsUtilities.replaceLine(destinationPath,noPasswdCommand,1);
			}
			
			logger.println(new String(Files.readAllBytes(destinationPath.toPath())));

			return executionResult;
			
					
		} catch (InterruptedException | IOException e) {
			
			e.printStackTrace();
			logger.println("An exception has been encountered during the command launch of K3/K4 report!");
		}
		return false;
	}
	

	/* (non-Javadoc)
	 * @see hudson.tasks.Recorder#getDescriptor()
	 */
	@Override
	public DescriptorImpl getDescriptor() {
		return (DescriptorImpl) super.getDescriptor();
	}

	/**
	 * The Class DescriptorImpl.
	 */
	@Extension
	public static final class DescriptorImpl extends BuildStepDescriptor<Publisher> implements Callable<List<String>, Throwable> {
		
		/** The Constant serialVersionUID. */
		private static final long serialVersionUID = 651137016888025315L;
		
		/**
		 * Instantiates a new descriptor impl.
		 */
		public DescriptorImpl() {
			load();
		}

		/**
		 * This method provides auto-completion items for the 'imsProjectName'
		 * field. Stapler finds this method via the naming convention.
		 *
		 * @param value            The text that the user entered.
		 * @param self the self
		 * @return the auto completion candidates
		 */
		public AutoCompletionCandidates doAutoCompleteImsProjectName(@QueryParameter String value,
				@AncestorInPath Item self) {

			AutoCompletionCandidates autoCompletionCandidates = new AutoCompletionCandidates();
			AbstractProject<?, ?> job = (AbstractProject<?, ?>) self;

			if (job == null) {

				return autoCompletionCandidates;

			}

			Label assignedLabelString = job.getAssignedLabel();
			if (assignedLabelString == null) {

				return autoCompletionCandidates;

			}

			List<Node> nodes = Lists.newArrayList(assignedLabelString.getNodes());
			if (nodes.isEmpty()) {

				return autoCompletionCandidates;

			}

			List<String> projects = Lists.newArrayList();

			try {

				projects = nodes.get(0).getChannel().call(DescriptorImpl.this);

			} catch (Throwable t) {

			}

			for (String project : projects)

				if (project.toLowerCase().contains(value.toLowerCase().trim())) {

					autoCompletionCandidates.add(project);

				}

			return autoCompletionCandidates;

		}

		/**
		 * This method is performing a check regarding metrics result path.
		 *
		 * @param value the value
		 * @return the form validation
		 * @throws IOException Signals that an I/O exception has occurred.
		 * @throws ServletException the servlet exception
		 */
		public FormValidation doCheckMetricsResultPath(@QueryParameter String value) throws IOException, ServletException {
			if (value.isEmpty()) {
				return FormValidation.error("Metrics result path must be set.");
			}
			
			if (value.length() < 3) {
				return FormValidation.warning("The provided path is too short.");
			}
			
			return FormValidation.ok();
		}
		
		/**
		 * Do check doors project file.
		 *
		 * @param value the value
		 * @return the form validation
		 * @throws IOException Signals that an I/O exception has occurred.
		 * @throws ServletException the servlet exception
		 */
		public FormValidation doCheckDoorsProjectFile(@QueryParameter String value) throws IOException, ServletException {
			if (value.length() > 0 && value.length() < 3) {
				return FormValidation.error("Insert a valid Path for doors file ");
			}
			
			
			return FormValidation.ok();
		}

		/* (non-Javadoc)
		 * @see hudson.tasks.BuildStepDescriptor#isApplicable(java.lang.Class)
		 */
		public boolean isApplicable(Class<? extends AbstractProject> aClass) {
			return true;
		}

		/* (non-Javadoc)
		 * @see hudson.model.Descriptor#getDisplayName()
		 */
		@Override
		public String getDisplayName() {
			return GlobalProperties.PLUGIN_NAME;
		}

		/* (non-Javadoc)
		 * @see hudson.model.Descriptor#configure(org.kohsuke.stapler.StaplerRequest, net.sf.json.JSONObject)
		 */
		@Override
		public boolean configure(StaplerRequest req, JSONObject formData) throws FormException {
			save();
			return super.configure(req, formData);
		}

		/**
		 * Default command to be executed.
		 *
		 * @return the string
		 */
		public String defaultImsCommandToBeExecuted() {
			return  IMS_DEFAULT_COMMAND;
		}
		
		/**
		 * Default jira command to be executed.
		 *
		 * @return the string
		 */
		public String defaultJiraCommandToBeExecuted() {
			return JIRA_RUN_REPORT_COMMAND;
		}

		/* (non-Javadoc)
		 * @see org.jenkinsci.remoting.RoleSensitive#checkRoles(org.jenkinsci.remoting.RoleChecker)
		 */
		@Override
		public void checkRoles(RoleChecker checker) throws SecurityException {
		}

		/* (non-Javadoc)
		 * @see hudson.remoting.Callable#call()
		 */
		@Override
		public List<String> call() throws Throwable {
			List<String> result = Lists.newArrayList();
			ProcessBuilder processBuilder = new ProcessBuilder("cmd", "/C", "im", "projects");
			processBuilder.redirectErrorStream(true);
			Process process = processBuilder.start();
			
			try (Scanner scanner = new Scanner(process.getInputStream());) {
				while (scanner.hasNextLine()) {
					String project = scanner.nextLine();
					if (!Strings.isNullOrEmpty(project)) {
						result.add(project.trim());
					}
				}
			}
			return result;
		}
	}

	/* (non-Javadoc)
	 * @see hudson.tasks.BuildStep#getRequiredMonitorService()
	 */
	@Override
	public BuildStepMonitor getRequiredMonitorService() {
		return BuildStepMonitor.BUILD;
	}

	/**
	 * Gets the command to be executed.
	 * If project name exists the <b>im runreport</b> command is executed, otherwise it will execute the default command
	 * and will create a new query
	 *
	 * @param queryNameExist the query name exist
	 * @param repoType the repo type
	 * @return the command to be executed
	 */
	public String getCommandToBeExecuted(boolean queryNameExist, String repoType, String envVar) {
		
		if (repoType.equals("IMS"))
		{
			return editImsCommand == null ? IMS_DEFAULT_COMMAND : editImsCommand.getImsCommandToBeExecuted();
		}
		
		else
		{
			return editJiraCommand == null ? envVar + " " + JIRA_RUN_REPORT_COMMAND : envVar + " ${jiraUrl} ${userId} ${passwdKey} " + editJiraCommand.getJiraCommandToBeExecuted().replaceAll(" ", "%%20");
			
		}
	}
	
	
	/**
	 * Gets the edits the command.
	 *
	 * @return the edits the command
	 */
	public EditImsCommand getEditImsCommand() {
		return editImsCommand;
	}
	
	/*public String defaultImsCommandToBeExecuted() {
		return new EditImsCommand().getImsCommandToBeExecuted();
	}*/
	
	/**
	 * Gets the edits the command.
	 *
	 * @return the edits the command
	 */
	public EditJiraCommand getEditJiraCommand() {
		return editJiraCommand;
	}
	
	/**
	 * Gets the metrics result path.
	 *
	 * @return the metrics result path
	 */
	public String getMetricsResultPath() {
		return metricsResultPath;
	}
	
	/**
	 * Gets the doors project file.
	 *
	 * @return the doors project file
	 */
	public String getDoorsProjectFile() {
		return doorsProjectFileName;
	}

	/**
	 * Gets the ims project name.
	 *
	 * @return the ims project name
	 */
	
	
	 /**
 	 * The Class EditCommand.
 	 */
 	public static class EditImsCommand {

		/** The command to be executed. */
		private final String imsCommandToBeExecuted;
		
		/**
		 * Instantiates a new edits the command.
		 *
		 * @param imsCommandToBeExecuted the ims command to be executed
		 */
		@DataBoundConstructor
		public EditImsCommand(String imsCommandToBeExecuted) {
			
			this.imsCommandToBeExecuted = imsCommandToBeExecuted;
		}
		

		/**
		 * Gets the command to be executed.
		 * Gets the command to be executed.
		 * @return the command to be executed
		 */
		public String getImsCommandToBeExecuted() {
			return imsCommandToBeExecuted;
		}
}
 	
	 /**
	 * The Class EditCommand.
	 * The Inner class that edits the JIRA command 
	 */
	public static class EditJiraCommand {

		/** The command to be executed. */
		private final String jiraCommandToBeExecuted;
		
		/**
		 * Instantiates a new edits the command.
		 *
		 * @param jiraCommandToBeExecuted the jira command to be executed
		 */
		@DataBoundConstructor
		public EditJiraCommand(String jiraCommandToBeExecuted) {
			this.jiraCommandToBeExecuted = jiraCommandToBeExecuted;
		}

		/**
		 * Gets the command to be executed.
		 *
		 * @return the command to be executed
		 */
		public String getJiraCommandToBeExecuted() {
			return jiraCommandToBeExecuted;
		}
}

	/**
	 * The Class MyBatchFile.
	 */
	private class MyBatchFile extends BatchFile {
		
		/** The file to redirect. */
		private File fileToRedirect;
		
		/**
		 * Instantiates a new my batch file.
		 *
		 * @param command the command
		 * @param fileToRedirect the file to redirect
		 */
		public MyBatchFile(String command, File fileToRedirect) {
			super(command);
			this.fileToRedirect = fileToRedirect;
		}

		/* (non-Javadoc)
		 * @see hudson.tasks.BatchFile#buildCommandLine(hudson.FilePath)
		 */
		@Override
		public String[] buildCommandLine(FilePath script) {
			return new String[] { "cmd.exe", "/C", "call", script.getRemote() };
		}

		/* (non-Javadoc)
		 * @see hudson.tasks.BatchFile#getContents()
		 */
		@Override
		protected String getContents() {
			String contents = super.getContents();
			String prefix = "@echo off" + NEW_LINE + "call :redirect> " + fileToRedirect.getAbsolutePath() + " 2>&1"
							+ NEW_LINE + "exit /b" + NEW_LINE + ":redirect" + NEW_LINE + "@echo on" + NEW_LINE;

			return LineEndingConversion.convertEOL(prefix + contents, LineEndingConversion.EOLType.Windows);
		}
	}
}
