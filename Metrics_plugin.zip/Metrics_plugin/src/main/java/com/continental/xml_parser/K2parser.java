/*
 * The Continental License
 * 
 * Copyright  2017(C) < S.C. Continental Automotive Romania S.R.L >
 * 
 * Created on    : Oct 10, 2014
 * Author        : uidu5465
 * 
 * Last revision : Sep 28, 2017 , 8:51:13 AM
 * Author        : uidt6436
 *
 * History from IMS Integrity Client:
 * 
 * $Log: K2parser.java  $
 * Revision 1.12 2017/10/10 09:47:30CEST Oparlescu, Vlad (uidt6436) 
 * RO : 649524
 * Revision 1.11 2017/09/28 08:12:20CEST Oparlescu, Vlad (uidt6436) 
 * RO 576256 : K2, K3,K4, K5 available in the console
 * 
 */
package com.continental.xml_parser;

import static com.continental.MetricsPlugin.EMetricsModelType.K2;
import static com.continental.utilities.GlobalProperties._KEY_DEVIATIONS_SAFETY_ABSOLUTE_MODIFIEDREUSED;
import static com.continental.utilities.GlobalProperties._KEY_DEVIATIONS_SAFETY_ABSOLUTE_NEWCODE;
import static com.continental.utilities.GlobalProperties._KEY_DEVIATIONS_NONSAFETY_ABSOLUTE_MODIFIEDREUSED;
import static com.continental.utilities.GlobalProperties._KEY_DEVIATIONS_NONSAFETY_ABSOLUTE_NEWCODE;
import static com.continental.utilities.GlobalProperties._KEY_ELOCSAFETY_TOTAL;
import static com.continental.utilities.GlobalProperties._KEY_ELOCSAFETY_MODIFIEDREUSED;
import static com.continental.utilities.GlobalProperties._KEY_ELOCSAFETY_NEWCODE;
import static com.continental.utilities.GlobalProperties._KEY_ELOCNONSAFETY_MODIFIEDREUSED;
import static com.continental.utilities.GlobalProperties._KEY_ELOCNONSAFETY_NEWCODE;

import java.io.File;
import java.util.logging.Logger;
import java.io.PrintStream;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.MetricsUtilities;
import com.continental.utilities.PropertiesReader;
import com.continental.utilities.ResultsSaver;

import hudson.model.Run;



// TODO: Auto-generated Javadoc
/**
 * The Class K2parser.
 */
public class K2parser extends AbstractParser {
	
	/** The k 2 value. */
	public double  k2value=0.0d;
	
	/** The build. */
	public Run<?, ?> build;
	
	/** The logger. */
	public PrintStream logger;
	
	/** The empty string. */
	public static String EMPTY_STRING= "";
	
	/** The K 2 file output. */
	public String K2FileOutput="K2.txt";
	
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(K5Parser.class.getName());
  
  /**
   * Instantiates a new k2parser.
   *
   * @param projectMetricsFile the project metrics file
   * @param propertiesReader the properties reader
   * @param build the build
   * @param metricsModel the metrics model
   * @param logger the logger
   */
  public K2parser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build, MetricsModel metricsModel,PrintStream logger) {
    super(projectMetricsFile, propertiesReader, build, metricsModel);
    this.build=build;
    this.logger = logger;
  }
  
  /**
   * Instantiates a new k 2 parser.
   *
   * @param projectMetricsFile the project metrics file
   * @param propertiesReader the properties reader
   * @param build the build
   * @param metricsModel the metrics model
   */
  public K2parser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build, MetricsModel metricsModel) {
	    super(projectMetricsFile, propertiesReader, build, metricsModel);
	    this.build=build;
	  }

  /* (non-Javadoc)
   * @see com.continental.xml_parser.AbstractParser#extractValuesFromXML()
   */
  @Override
  protected void extractValuesFromXML() {
	k2value= k2Formula();
	logger.println("The K2 calculated value is: " + k2value + "\n");
    metricsModel.addMetrics(K2, build.getNumber(), k2value);
    //create K2.txt in build number folder/ copy K2.txt in KPI folder at project level
    createAndCopyK2toKPI();
  }

	/**
	 * Computes the K2 formula which represents the coding rules violations.
	 *
	 * @return the double coding rule violation density result,rounded in order to obtain a number compounded of 4 decimal for accuracy reasons
	 */
	private double k2Formula() {
		double formula = 0.0d;
		
		double oldTotalEloc = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_ELOCSAFETY_TOTAL));
		
		double newTotalEloc = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_ELOCSAFETY_MODIFIEDREUSED))
				         	+ parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_ELOCSAFETY_NEWCODE))
				         	+ parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_ELOCNONSAFETY_MODIFIEDREUSED))
				         	+ parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_ELOCNONSAFETY_NEWCODE));
		
				         
		double deviationSATotal = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_DEVIATIONS_SAFETY_ABSOLUTE_MODIFIEDREUSED))
								+ parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_DEVIATIONS_SAFETY_ABSOLUTE_NEWCODE))
								+ parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_DEVIATIONS_NONSAFETY_ABSOLUTE_MODIFIEDREUSED))
								+ parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_DEVIATIONS_NONSAFETY_ABSOLUTE_NEWCODE));
		if (newTotalEloc != 0.0) 
		{
			formula = (double) (deviationSATotal / newTotalEloc);
		}
		else if (oldTotalEloc != 0.0)
		{
			formula = (double) (deviationSATotal / oldTotalEloc);
		}
		return Math.round(formula * 10000.00) / 10000.00;
	}
	
	/**
	 * void function, create K2.txt in build number folder
	 * copy K2.txt from build folder to KPI folder
	 */
	public void createAndCopyK2toKPI(){
		ResultsSaver saver = new ResultsSaver(build);
		File metricsfolder = MetricsUtilities.getMetricsFolder(build);
		File kpiFolder = MetricsUtilities.getKPIFolder(build);
		
		try{
			//create K2.txt in build No folder
			saver.createFile(metricsfolder, K2FileOutput, String.valueOf(k2value), EMPTY_STRING);
			LOG.info(K2FileOutput +"is created.");
			//copy K2.txt from build No to KPI folder
			MetricsUtilities.copyFile(metricsfolder.toString(),kpiFolder.toString(), K2FileOutput);
			LOG.info(K2FileOutput +"is copied to KPI folder.");
		}catch(Exception e){
			LOG.info(K2FileOutput +"can not be copied to KPI folder.");
		}
	}
}
