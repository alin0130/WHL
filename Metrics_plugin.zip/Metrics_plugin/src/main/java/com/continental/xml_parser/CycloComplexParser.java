/*
 * The Continental License
 * 
 * Copyright  2017(C) < S.C. Continental Automotive Romania S.R.L >
 * 
 * Created on    : Oct 10, 2014
 * Author        : uidw6888
 * 
 * Last revision : Oct 10, 2017 , 9:44:27 AM
 * Author        : uidt6436
 *
 * History from IMS Integrity Client:
 * 
 * $Log: CycloComplexParser.java  $
 * Revision 1.8 2017/10/10 09:47:29CEST Oparlescu, Vlad (uidt6436) 
 * RO : 649524
 * 
 */
package com.continental.xml_parser;

import static com.continental.MetricsPlugin.EMetricsModelType.CYCLO_COMPLEX;
import static com.continental.utilities.GlobalProperties._KEY_CYCLO_BETWEEN_15_AND_30;
import static com.continental.utilities.GlobalProperties._KEY_CYCLO_MORE_THAN_30;

import java.io.File;
import java.util.logging.Logger;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.MetricsUtilities;
import com.continental.utilities.PropertiesReader;
import com.continental.utilities.ResultsSaver;

import hudson.model.Run;

// TODO: Auto-generated Javadoc
/**
 * The Class CycloComplexParser.
 */
public class CycloComplexParser extends AbstractParser {

	
	/** The cyclo output. */
	private String cycloOutput = "CycloOutput.txt";
	
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(K5Parser.class.getName());
	
	/**
	 * Instantiates a new cyclo complex parser.
	 *
	 * @param projectMetricsFile the project metrics file
	 * @param propertiesReader the properties reader
	 * @param build the build
	 * @param metricsModel the metrics model
	 */
	public CycloComplexParser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build, MetricsModel metricsModel) {
		super(projectMetricsFile, propertiesReader, build, metricsModel);
	}
	
	/* (non-Javadoc)
	 * @see com.continental.xml_parser.AbstractParser#extractValuesFromXML()
	 */
	@Override
	protected void extractValuesFromXML() {
		
		double cycloBtwn = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_CYCLO_BETWEEN_15_AND_30));
		double cycloOver = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_CYCLO_MORE_THAN_30));
		File metricsfolder = MetricsUtilities.getMetricsFolder(build);
		metricsModel.addMetrics(CYCLO_COMPLEX, build.getNumber(),cycloBtwn,cycloOver);
		
		/*
		 * Create the CycloOutput.txt file containing the cycloBtwn(first line) and cycloOver(second line) and copy it inside KPI folder
		 */
		boolean createResult = new ResultsSaver(build).createFile(metricsfolder,cycloOutput,String.valueOf(cycloBtwn),String.valueOf(cycloOver)) ? true : false;
		boolean copyResult = MetricsUtilities.copyFile(metricsfolder.toString(), MetricsUtilities.getKPIFolder(build).toString(), cycloOutput) ? true : false ;

		LOG.info(createResult ? "The Cyclomatic file has been created" : "The Cyclomatic file hasn't been created due to an encountered exception");
		LOG.info(copyResult ? "The Cyclomatic file has been copied to the KPI folder" : "The Cyclomatic file hasn't been copied due to an encountered exception");
		
		
	}
}
