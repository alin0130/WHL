package com.continental.xml_parser;

import static com.continental.MetricsPlugin.EMetricsModelType.K5;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;

import java.io.File;
import java.util.ArrayList;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.MetricsUtilities;
import com.continental.utilities.PropertiesReader;

public class K5ParserIterateBuilds extends AbstractParser {
	File projectK5File; // project file containing values for K5 and the date when the file was generated
	MetricsUtilities mu = new MetricsUtilities();
	public AbstractProject<?, ?> project;
	
	public K5ParserIterateBuilds(File projectMetricsFile, PropertiesReader propertiesReader, AbstractBuild<?, ?> build, MetricsModel metricsModel) {
		super(projectMetricsFile, propertiesReader, build, metricsModel);
		this.projectK5File = projectMetricsFile;
		this.build = build;
	}
	
	@Override
	protected void extractValuesFromXML() {
		// TODO Auto-generated method stub
		metricsModel.addMetrics(K5, build.getNumber(), getValue());
	}
	
	public double getValue() {
		double k5Value = 0.0d;
		// projectK5File is null if the file is empty
		if (projectK5File != null) {
			ArrayList<String> oldFileValueFile = mu.getValueFromTxtFile(projectK5File);
			k5Value = Double.parseDouble(mu.getTxtFileLineValue(oldFileValueFile, K5Parser.FIRST_LINE)); // 1st
		}
		return k5Value;
	}
}
