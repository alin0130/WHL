/*
 * The Continental License
 * 
 * Copyright  2017(C) < S.C. Continental Automotive Romania S.R.L >
 * 
 * Created on    : Oct 10, 2014
 * Author        : uidw6888
 * 
 * Last revision : Oct 10, 2017 , 9:48:15 AM
 * Author        : uidt6436
 *
 * History from IMS Integrity Client:
 * 
 * $Log: K4Parser.java  $
 * Revision 1.16 2017/10/10 09:47:32CEST Oparlescu, Vlad (uidt6436) 
 * RO : 649524
 * 
 */
package com.continental.xml_parser;

import static com.continental.MetricsPlugin.EMetricsModelType.K4;
import static com.continental.utilities.GlobalProperties._KEY_ELOCSAFETY_TOTAL;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.util.Optional;
import java.util.logging.Logger;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.MetricsUtilities;
import com.continental.utilities.PropertiesReader;
import com.continental.utilities.ResultsSaver;
import com.google.common.base.Charsets;
import com.google.common.base.Strings;

import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;
import hudson.FilePath;
import hudson.model.Run;

// TODO: Auto-generated Javadoc
/**
 * K4Parser is adding to the metrics model the information about K4 KPI.
 * </p>
 * In order to extract the K4 model, the file <b>K4.json</b> is first searched
 * in the
 * <q>job/builds/[build_number]/metrics/</q> folder.
 * </p>
 * If this file is discovered then it is deserialized and added to metrics
 * model.
 * </p>
 * If the file <b>K4.json</b> is not found, then the parsing of the file
 * <b>K3_K4_query_result.txt</b> is performed.
 * 
 * </p>
 * The parsing is done applying the following logic:
 * <p>
 * <ul>
 * <li>compute
 * <q>count = select COUNT(ID) FROM records WHERE DETECTED BY =
 * "external customer";</q></li>
 * <li>get ELOC from projectMetrics.xml</li>
 * <li>compute KELOC = ELOC / 1000</li>
 * <li>add to metrics model the value calculated as
 * <q>count / KELOC</q></li>
 * </ul>
 * 
 * </code>
 * </p>
 * 
 * 
 * @author uidu5465
 *
 */

public class K4Parser extends AbstractParser {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(K4Parser.class.getName());
	
	/** The Constant EMPTY_STRING. */
	private static final String EMPTY_STRING = "";
	
	/** The Constant KILO_AMPLIFIER. */
	private static final double KILO_AMPLIFIER = 1_000.0d;
	
	/** The Constant EXTERNAL_CUSTOMER. */
	private static final String EXTERNAL_CUSTOMER = "external customer";
	
	/** The Constant TEST. */
	private static final String TEST = "\"test\"";
	
	/** The Constant MAX_PRECISION. */
	private static final int MAX_PRECISION = (int) Math.pow(10.0d, 15.0d);
	
	/** The build full displayname. */
	private String buildFullDisplayname = EMPTY_STRING;
	
	/** The k 4 value. */
	public double  k4value=0.0d;
	
	/** The logger. */
	public PrintStream logger;
	
	/**
	 * Instantiates a new k 4 parser.
	 *
	 * @param projectMetricsFile the project metrics file
	 * @param propertiesReader the properties reader
	 * @param build the build
	 * @param metricsModel the metrics model
	 * @param logger the logger
	 */
	public K4Parser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build, MetricsModel metricsModel, PrintStream logger) {
		super(projectMetricsFile, propertiesReader, build, metricsModel);
		this.buildFullDisplayname = build.getFullDisplayName();
		this.logger = logger;
	}
	
	/**
	 * Instantiates a new k 4 parser.
	 *
	 * @param projectMetricsFile the project metrics file
	 * @param propertiesReader the properties reader
	 * @param build the build
	 * @param metricsModel the metrics model
	 */
	public K4Parser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build, MetricsModel metricsModel) {
		super(projectMetricsFile, propertiesReader, build, metricsModel);
		this.buildFullDisplayname = build.getFullDisplayName();	
	}

	/* (non-Javadoc)
	 * @see com.continental.xml_parser.AbstractParser#extractValuesFromXML()
	 */
	@Override
	protected void extractValuesFromXML() {
		Optional<File> k4JSONFileOptional = MetricsUtilities.getK4JsonFile(build);
		if (k4JSONFileOptional.isPresent()) {
			LOG.info(buildFullDisplayname + "\t - Since the file: " + k4JSONFileOptional.get()+ " exists, start deserializing it.");
			Optional<Double> optionalValue = deserializeFileContent(k4JSONFileOptional);
			if (!optionalValue.isPresent()) {
				return;
			}
			 k4value = optionalValue.get();

			LOG.info(buildFullDisplayname + "\t - Value extracted after deserialization of the file: " + k4value);
			metricsModel.addMetrics(K4, build.getNumber(), k4value);
		}

		File destinationPath = MetricsUtilities.getK3AndK4File(build);
		if (!destinationPath.exists()) {
			return;
		}

		LOG.info(buildFullDisplayname + "\t - Since the file: " + destinationPath + " exists, start parsing it.");
		double calculateK4Value = calculateK4Value(destinationPath);
		logger.println("The K4 calculated value is: " + calculateK4Value + "\n");
		LOG.info(buildFullDisplayname + "\t - Value extracted after parsing of the file: "+ new JSONSerializer().serialize(calculateK4Value));

		metricsModel.addMetrics(K4, build.getNumber(), calculateK4Value);
		saveValuesToJSONFile(calculateK4Value);
		createAndCopyK4toKPI(calculateK4Value);
	}

	/**
	 * create and copy K4.txt from build level to KPI folder , which is at the same level with build folder. this is done on the master
	 *
	 * @param calculateK4Value the calculate K 4 value
	 */
	public void createAndCopyK4toKPI(double calculateK4Value) {

		/*K4.json is created for  each buid inside metrics folder (ex: D:\Jenkins\jobs\JobName\builds\BuildNumber\metrics\K4.json) */
		File metricsfolder = MetricsUtilities.getMetricsFolder(build);
		/* KPI folder at the same level with build folder in the job structure on the master */
		File kpiFolder = MetricsUtilities.getKPIFolder(build);
		ResultsSaver saver = new ResultsSaver(build);
	    String K4FileOutput="K4.txt";

		try{
			/* create K4.txt in build No folder */
			saver.createFile(metricsfolder, K4FileOutput, String.valueOf(calculateK4Value), EMPTY_STRING);
			LOG.info(K4FileOutput +"is created.");
			/* copy K4.txt from build No to KPI folder */
			MetricsUtilities.copyFile(metricsfolder.toString(), kpiFolder.toString(),K4FileOutput);
			LOG.info(K4FileOutput + " is copied to KPI folder.");
		} catch (Exception e) {
			LOG.info(K4FileOutput + " can not be copied to KPI folder.");
		}
	}
	
	
	/**
	 * Save values to JSON file.
	 *
	 * @param calculateK4Value the calculate K 4 value
	 */
	private void saveValuesToJSONFile(double calculateK4Value) {
		String serializeK4Value = new JSONSerializer().serialize(calculateK4Value);
		File createK4JSONFile = MetricsUtilities.createK4JSONFile(build);
		FilePath source = new FilePath(createK4JSONFile);
		try {
			source.copyFrom(new ByteArrayInputStream(serializeK4Value.getBytes(Charsets.UTF_8)));
		} catch (IOException | InterruptedException e) {
			LOG.warning(buildFullDisplayname + "\t - Exception saving values to JSON file: "+ createK4JSONFile.getPath() + "\t" + e.getMessage());
		}
	}

	/**
	 * Deserialize file content.
	 *
	 * @param k4jsonFileOptional the k 4 json file optional
	 * @return the optional
	 */
	private Optional<Double> deserializeFileContent(Optional<File> k4jsonFileOptional) {
		String fileContent = EMPTY_STRING;
		try {
			fileContent = new String(Files.readAllBytes(k4jsonFileOptional.get().toPath()));
		} catch (IOException e) {
			return Optional.empty();
		}

		if (Strings.isNullOrEmpty(fileContent)) {
			return Optional.empty();
		}

		JSONDeserializer<Double> deserializer = new JSONDeserializer<>();
		return Optional.ofNullable(deserializer.deserialize(fileContent));
	}

	/**
	 * Calculate K 4 value.
	 *
	 * @param destinationPath the destination path
	 * @return the double
	 */
	private double calculateK4Value(File destinationPath) {
		double result = 0.0d;
		double totalEloc = 0.0d;
		double totalKEloc=0.0d;
		long count=0;
		
		LOG.finest(buildFullDisplayname + "\t - Calculate K4 value from : " + destinationPath + ".");
		try {
			totalEloc = parser.parseWithXPath(projectMetricsFile,propertiesReader.readFromProperties(_KEY_ELOCSAFETY_TOTAL));
			LOG.finest(buildFullDisplayname + "\t - Total ELOC = " + totalEloc);
		   }catch(Exception e){}
			
		try {
			totalKEloc = totalEloc / KILO_AMPLIFIER;
			LOG.finest(buildFullDisplayname + "\t - Total KELOC = " + totalKEloc);
		    } catch(Exception e) {}
			
		try {
			count = Files.readAllLines(destinationPath.toPath()).stream().filter(p -> p.toLowerCase().contains(EXTERNAL_CUSTOMER) && !p.toLowerCase().contains(TEST)).count();
			LOG.finest(buildFullDisplayname + "\t - Total number of records that contains \"external customer\" = "+ count);
	        } catch(Exception e) {} 
		
			if (totalKEloc != 0.0d) {
				result = (double)(Math.floor(count / totalKEloc * MAX_PRECISION) / MAX_PRECISION);
				LOG.finest(buildFullDisplayname + "\t - Calculated K4 Value = " + result);
			}
			
			return result;
	}
}
