/*
 * The Continental License
 * 
 * Copyright  2017(C) < S.C. Continental Automotive Romania S.R.L >
 * 
 * Created on    : Oct 10, 2014
 * Author        : uidu5465
 * 
 * Last revision : Sep 28, 2017 , 8:48:41 AM
 * Author        : uidt6436
 *
 * History from IMS Integrity Client:
 * 
 * $Log: K5Parser.java  $
 * Revision 1.4 2017/09/28 08:12:20CEST Oparlescu, Vlad (uidt6436) 
 * RO 576256 : K2, K3,K4, K5 available in the console
 * 
 */
package com.continental.xml_parser;

import static com.continental.MetricsPlugin.EMetricsModelType.K5;

import java.io.File;
import java.io.PrintStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.logging.Logger;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.GlobalProperties;
import com.continental.utilities.MetricsUtilities;
import com.continental.utilities.PropertiesReader;
import com.continental.utilities.ResultsSaver;

import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Project;
import hudson.model.Run;
import hudson.util.RunList;

public class K5Parser extends AbstractParser {
	static int FIRST_LINE=0;
	static int SECOND_LINE=1;
	static int THIRD_LINE=2;
	static int FOURTH_LINE=3;
	
	File projectMetricsFile; // project file containing values for K5 and the date when the file was generated
	private static String K5FileOutput = "K5.txt";
	private MetricsUtilities mu=new MetricsUtilities();
	public  AbstractProject<?, ?> project;
	public PrintStream logger;
	private AbstractBuild<?, ?>  build;
	private static final Logger LOG = Logger.getLogger(K5Parser.class.getName());
	
	
  public K5Parser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build, AbstractProject<?, ?> project, MetricsModel metricsModel) {
    super(projectMetricsFile, propertiesReader, build, metricsModel);
    this.projectMetricsFile=projectMetricsFile;
    this.project=project;
  }
  
  public K5Parser(File projectMetricsFile, PropertiesReader propertiesReader, AbstractBuild<?, ?> build, MetricsModel metricsModel, PrintStream logger) {
	    super(projectMetricsFile, propertiesReader, build, metricsModel);
	    this.projectMetricsFile=projectMetricsFile;
	    this.build=build;
	    this.logger = logger;
  }

 
@Override
	protected void extractValuesFromXML() {
		if (k5logic() == true) {
			double k5value = k5Formula(projectMetricsFile);
			metricsModel.addMetrics(K5, build.getNumber(), k5value);
			
		}
	}

	/**
	 * @return a boolean value. if it's true the the current k5 value will be displayed on the graph, otherwise the current k5 value is not displayed on the graph
	 * create the K5.txt file for the current build - 1. if the previous builds doesn't have a K5.txt file
	 *  											- 2. if the current k5 value is different from the value in k5.txt file for the previous build
	 */

	public boolean k5logic() {
		boolean show = false;
		ResultsSaver saver = new ResultsSaver(build);
	//	ArrayList<String> fileValues = mu.getValueFromTxtFile(projectMetricsFile); 
		double currentBuildK5formula = k5Formula(projectMetricsFile);//current build k5 value
		logger.println("The K5 calculated value is: " + currentBuildK5formula + "\n");
		LocalDate currentBuildK5date = getDate(projectMetricsFile, FOURTH_LINE); // the line contains the date value
		File k5File = getPreviousBuilds(build, GlobalProperties.METRICS_FOLDER, K5FileOutput);
		if (k5File == null) {
			show = true;
		} else {
			if (k5File != null) {
				k5File = new File(k5File, K5FileOutput);
				ArrayList<String> oldFileValueFile = mu.getValueFromTxtFile(k5File);
				double oldFileValue = Double.parseDouble(mu.getTxtFileLineValue(oldFileValueFile, FIRST_LINE)); // 1st value
				if (showK5(currentBuildK5formula, oldFileValue) == true) {
					show = true;
				}
			}
		}
		if(show==true){
			File metricsfolder = MetricsUtilities.getMetricsFolder(build);
			File kpiFolder = MetricsUtilities.getKPIFolder(build);
			
			saver.createFile(metricsfolder, K5FileOutput, String.valueOf(currentBuildK5formula), currentBuildK5date.toString());
			LOG.info(K5FileOutput +"is created.");
			mu.copyFile(metricsfolder.toString(),kpiFolder.toString(), K5FileOutput);
		}
		return show;
	}
	
	/**
	 * @param currentBuildValue 
	 * @param oldValue : 
	 * @return False if the @currentBuildValue equals @ oldValue values, otherwise return True
	 */
	public boolean showK5(double currentBuildValue, double oldValue) {
		boolean show;
		if ((currentBuildValue == oldValue) || currentBuildValue==0.0) {
			show = false;
		} else {
			show = true;
		}
		return show;
	}
	
	/**
	 * @param fileName
	 * @return a double  value, representing the K5 value
	 */
	private double k5Formula(File fileName) {
		double formula = 0.0d;
		ArrayList<String> fileValues=mu.getValueFromTxtFile(projectMetricsFile);
		if (!fileValues.isEmpty()) {
			double value1 = Double.parseDouble(mu.getTxtFileLineValue(fileValues, SECOND_LINE));
			double value2 = Double.parseDouble(mu.getTxtFileLineValue(fileValues, THIRD_LINE));
			formula = calculateK5Value(value2, value1);
		}
		return formula;
	}
	
	/**
	 * @param fileName 
	 * @param lineNumber : the line number where the Date exists
	 * @return LocalDate convert the string representing the date (format dd-mm-yyy) into LocalDate variable, with format dd/mm/yyyy
	 */
	private LocalDate getDate(File fileName, int lineNumber){
		ArrayList<String> fileValues=mu.getValueFromTxtFile(projectMetricsFile);
		String standardDate="01-01-1970";
		LocalDate date=convertStringToDate(standardDate);
		if (!fileValues.isEmpty()) {
			String dateK5file = mu.getTxtFileLineValue(fileValues, lineNumber);
			dateK5file = dateK5file.replace("-", "/");
			date = convertStringToDate(dateK5file);
		}
		return date;
	}
	
	/**
	 * @param value1 a double value
	 * @param value2 a double value
	 * @return value1/value2 - 2 decimals round
	 */
	private double calculateK5Value(double value1, double value2){
		double formula = 0.0d;
		if (value2 != 0.0) {
			formula = (double) (value1 / value2);
		}
		formula = Math.round(formula * 10000.00) / 100.00;
		
		return formula;
	}
	
	/**
	 * @param build current build
	 * @param folderName - represents a folder created inside the build folder
	 * @param fileName - the file name to find
	 * @return a file Object, representing the absolute path
	 */
	public File getPreviousBuilds(AbstractBuild<?, ?> build, String folderName, String fileName) {
		Project project = (Project) build.getProject();
		RunList<?> allBuilds = project.getBuilds();
		ListIterator<?> listIterator = allBuilds.listIterator();
		File filePathFolder=null;
		File filePath;
		boolean ok= false;
		
		while (listIterator.hasNext()) {
			AbstractBuild<?, ?> nextBuild = (AbstractBuild<?, ?>) listIterator.next();
			filePath = nextBuild.getRootDir();
			filePathFolder = new File(filePath, folderName);
			filePath = new File(filePathFolder, fileName);
			
			if (filePath.exists()) {
				ok=true;
				break;
			}else{
				if (!filePath.exists()) {
					continue;
				}
			}
		}
		if (ok == false) {
			filePathFolder = null;
		}
		
		return filePathFolder;
	}
	
	/**
	 * @param date - a string
	 * @return conversion of a string in a LocalDate, ussing the dd/mm/yyyy pattern format
	 */
	public LocalDate convertStringToDate(String date) {
		date=date.replace("-", "/");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate newDate= LocalDate.parse(date, formatter);
		return newDate;
	}
	
	/**
	 * @param date string in dd-mm-yyyy format
	 * @return @dates conversion in a LocalDate value
	 */
	public LocalDate convertStringToDate2Version(String date) {
		date=date.replace("-", "/");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYY/MM/dd");
		LocalDate newDate= LocalDate.parse(date, formatter);
		return newDate;
	}
	
}
