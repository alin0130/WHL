package com.continental.xml_parser;

import static com.continental.MetricsPlugin.EMetricsModelType.BUILD_WARNINGS;
import static com.continental.MetricsPlugin.EMetricsModelType.LINKER_WARNINGS;
import static com.continental.utilities.GlobalProperties._KEY_BUILD_WARNINGS;
import static com.continental.utilities.GlobalProperties._KEY_LINKER_WARNINGS;

import java.io.File;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.PropertiesReader;

import hudson.model.Run;

public class BuildReportsParser extends AbstractParser {

  public BuildReportsParser(File projectMetricsFile, PropertiesReader propertiesReader,
      Run<?, ?> build, MetricsModel metricsModel) {

    super(projectMetricsFile, propertiesReader, build, metricsModel);

  }

  @Override
  protected void extractValuesFromXML() {

    extractBuildWarningsValues();
    extractLinkerWarningsValues();
  }

  private void extractBuildWarningsValues() {

    String buildWarnings = propertiesReader.readFromProperties(_KEY_BUILD_WARNINGS);

    metricsModel.addMetrics(BUILD_WARNINGS, build.getNumber(),
        parser.parseWithXPath(projectMetricsFile, buildWarnings));

  }

  private void extractLinkerWarningsValues() {

    String linkerWarnings = propertiesReader.readFromProperties(_KEY_LINKER_WARNINGS);

    metricsModel.addMetrics(LINKER_WARNINGS, build.getNumber(),
        parser.parseWithXPath(projectMetricsFile, linkerWarnings));

  }

}
