package com.continental.xml_parser;

import java.io.File;
import java.util.concurrent.Callable;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.PropertiesReader;
import com.continental.utilities.XPathParser;

import hudson.model.Run;

public abstract class AbstractParser implements Callable<Void> {

	protected File projectMetricsFile;

	protected PropertiesReader propertiesReader;

	protected Run<?,?> build;

	protected XPathParser parser = new XPathParser();

	protected MetricsModel metricsModel;

	public AbstractParser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?,?> build, MetricsModel metricsModel) {

		super();

		this.projectMetricsFile = projectMetricsFile;

		this.propertiesReader = propertiesReader;

		this.build = build;

		this.metricsModel = metricsModel;

	}

	@Override
	public Void call() {

		extractValuesFromXML();

		return null;

	}

	protected abstract void extractValuesFromXML();
 
}
