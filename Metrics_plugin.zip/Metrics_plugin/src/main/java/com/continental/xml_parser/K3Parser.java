package com.continental.xml_parser;

import static com.continental.MetricsPlugin.EMetricsModelType.K3;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;

import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.io.FileReader;

import com.continental.MetricsPlugin.CausedBy;
import com.continental.MetricsPlugin.K4Model;
import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.MetricsUtilities;
import com.continental.utilities.PropertiesReader;
import com.google.common.base.Charsets;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;
import flexjson.transformer.ArrayTransformer;
import hudson.FilePath;
import hudson.model.Run;

/**
 * 
 * K3Parser is adding to the metrics model the information about K3 KPI.
 * </p>
 * In order to extract the K3 model, the file <b>K3.json</b> is first searched
 * in the
 * <q>job/builds/[build_number]/metrics/</q> folder.
 * </p>
 * If this file is discovered then it is deserialized and added to metrics
 * model.
 * </p>
 * If the file <b>K3.json</b> is not found, then the parsing of the file
 * <b>K3_K4_query_result.txt</b> is performed.
 * 
 * </p>
 * The parsing is done applying the following logic:
 * 
 * <p>
 * <code>
 * 
 * select COUNT(ID) FROM records GROUP BY "Caused by";
 * 
 * </code>
 * </p>
 * 
 * @author uidu5465
 *
 */
public class K3Parser extends AbstractParser {
	private static final Logger LOG = Logger.getLogger(K3Parser.class.getName());
	private static final String EMPTY_STRING = "";
	private static final String LINE_PATTERN = "^\"(?<ID>\\d+)\",\"(?<PROJECT>[^\"]*)\",\"(?<DETECTEDBY>[^\"]*)\",\"(?<CAUSEDBY>[^\"]*)\",$";
	private Map<String, Double> causedbyNumberMap = Maps.newTreeMap();
	private String buildFullDisplayname = EMPTY_STRING;
	
	/** The logger. */
	public PrintStream logger;
	
	/**
	 * Instantiates a new k 3 parser.
	 *
	 * @param projectMetricsFile the project metrics file
	 * @param propertiesReader the properties reader
	 * @param build the build
	 * @param metricsModel the metrics model
	 * @param logger the logger
	 */
	public K3Parser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build, MetricsModel metricsModel, PrintStream logger) {
		super(projectMetricsFile, propertiesReader, build, metricsModel);
		this.buildFullDisplayname = build.getFullDisplayName();
		initialize();
		this.logger = logger;
	}
	
	/**
	 * Instantiates a new k 3 parser.
	 *
	 * @param projectMetricsFile the project metrics file
	 * @param propertiesReader the properties reader
	 * @param build the build
	 * @param metricsModel the metrics model
	 */
	public K3Parser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build, MetricsModel metricsModel) {
		super(projectMetricsFile, propertiesReader, build, metricsModel);
		this.buildFullDisplayname = build.getFullDisplayName();
		initialize();
	}

	/* (non-Javadoc)
	 * @see com.continental.xml_parser.AbstractParser#extractValuesFromXML()
	 */
	@Override
	protected void extractValuesFromXML() {
		Optional<File> k3JSONFileOptional = MetricsUtilities.getK3JsonFile(build);
		if (k3JSONFileOptional.isPresent()) {
			LOG.info(buildFullDisplayname + "\t - Since the file: " + k3JSONFileOptional.get() + " exists, start deserializing it.");
			Optional<double[]> transformedK3ValuesFromJsonOptional = deserializeFileContent(k3JSONFileOptional);
			if (!transformedK3ValuesFromJsonOptional.isPresent()) {
				return;
			}
			double[] ds = transformedK3ValuesFromJsonOptional.get();
			LOG.info(buildFullDisplayname + "\t - Values extracted after deserialization of the file: " + new JSONSerializer().serialize(ds));
			metricsModel.addMetrics(K3, build.getNumber(), ds);
		} else {
			
			File destinationPath = MetricsUtilities.getK3AndK4File(build);
			if (!destinationPath.exists()) {
				return;
			}
			LOG.info(buildFullDisplayname + "\t - Since the file: " + destinationPath + " exists, start parsing it.");
			causedbyNumberMap.putAll(processK3Map(destinationPath));
			double[] calculatedValues = getCalculatedValues(causedbyNumberMap.values());
			
			//Call the console display method
			displayValues (calculatedValues, logger);
			logger.println("\n");
			
			LOG.info(buildFullDisplayname + "\t - Values extracted after parsing of the file: "+ new JSONSerializer().serialize(calculatedValues));
			metricsModel.addMetrics(K3, build.getNumber(), calculatedValues);
			saveValuesToJSONFile(calculatedValues);
		}
	}
	
	/**
	 * Display values of K3 coefficient inside build console.
	 *
	 * @param calculatedValues the calculated values of K3
	 * @param logger the logger that prints the data
	 */
	private void displayValues (double[] calculatedValues, PrintStream logger) {
		logger.println("The K3 calculated values are: ");
		for (int i = 0; i < calculatedValues.length; i++ ) {
			String name = null;
			switch(i) {
			case 0: name = "Architecture";
					break;
			case 1: name = "Calibration";
					break;
			case 2: name = "Design";
					break;
			case 3: name = "Integration";
					break;
			case 4: name = "Requirement";
					break;
			case 5: name = "Solution";
					break;
			case 6: name = "Test";
					break;
			case 7: name = "Unspecified";
					break;
			default: //Do nothing
			}
			logger.println(String.format("%1$50s", name + " : " + calculatedValues[i]));
		}
	}

	private void initialize() {
		for (CausedBy causedBy : CausedBy.values()) {
			causedbyNumberMap.put(causedBy.toString(), 0.0d);
		}
	}

	private Optional<double[]> deserializeFileContent(Optional<File> k3JSONFileOptional) {
		String fileContent = EMPTY_STRING;
		try {
			fileContent = new String(Files.readAllBytes(k3JSONFileOptional.get().toPath()));
		} catch (IOException e) {
			return Optional.empty();
		}
		if (Strings.isNullOrEmpty(fileContent)) {
			return Optional.empty();
		}

		JSONDeserializer<ArrayList<Double>> deserializer = new JSONDeserializer<>();
		List<Double> result = deserializer.deserialize(fileContent, ArrayList.class);

		return Optional.ofNullable(getCalculatedValues(result));
	}

	private void saveValuesToJSONFile(double[] calculatedValues) {
		String serializeArray = serializeArray(calculatedValues);
		File createK3JSONFile = MetricsUtilities.createK3JSONFile(build);
		FilePath source = new FilePath(createK3JSONFile);
		try {
			source.copyFrom(new ByteArrayInputStream(serializeArray.getBytes(Charsets.UTF_8)));
		} catch (IOException | InterruptedException e) {
			LOG.warning(buildFullDisplayname + "\t - Exception saving values to JSON file: " + createK3JSONFile.getPath() + "\t" + e.getMessage());
		}
	}
	

	private String serializeArray(double[] calculatedValues) {
		return new JSONSerializer().transform(new ArrayTransformer(), String.class).serialize(calculatedValues);
	}

	private double[] getCalculatedValues(Collection<Double> values) {
		return values.stream().mapToDouble(Double::doubleValue).toArray();
	}

	private Map<String, Double> processK3Map(File destinationPath) {
		Map<String, Double> result = Maps.newTreeMap();
		Map<CausedBy, List<K4Model>> collect = parse(destinationPath).stream().filter(Objects::nonNull).collect(Collectors.groupingBy(K4Model::getCausedBy));
		collect.forEach((k, v) -> {
			result.put(k.toString(), (double) v.size());
		});
		return result;
	}
	
	private Map<String, Double> parseJson (File destinationPath) {
		Map<String, Double> result = Maps.newTreeMap();
		int problemReports = 0;
		
		JSONParser jsonParser = new JSONParser();
		
		try {
			
			JSONObject obj =  (JSONObject)jsonParser.parse(new FileReader(destinationPath));
			
			JSONArray issues = (JSONArray) obj.get("issues");
			
			
			for (Object counterOne : issues)
			  {
				JSONObject issue = (JSONObject) counterOne;

				JSONObject fields = (JSONObject)issue.get("fields");
				
				JSONObject issuetype = (JSONObject)fields.get("issuetype");
				
				if (issuetype.get("name").equals("Problem Report (PR)"))
					problemReports++;
			   
			  }
			
		}
		
		catch (IOException | ParseException e) {
			e.printStackTrace();
		}
		
		
		
		return result;
	}

	private List<K4Model> parse(File destinationPath) {
		List<K4Model> result = Lists.newArrayList();
		try {
			Files.readAllLines(destinationPath.toPath()).stream().filter(line -> !Strings.isNullOrEmpty(line))
					.filter(line -> line.matches(LINE_PATTERN)).forEach(line -> {
						result.add(parseLine(line));
					});

		} catch (IOException e) {
			LOG.warning(buildFullDisplayname + "\t - Exception parsing the file: " + destinationPath + "\t" + e.getMessage());
		}
		
		return result;
	}

	private K4Model parseLine(String line) {

		LOG.finest(buildFullDisplayname + "\t - Parsing line: " + line + ".");
		K4Model k3Model = new K4Model();
		Pattern pattern = Pattern.compile(LINE_PATTERN);
		Matcher matcher = pattern.matcher(line);
		
		while (matcher.find()) {
			k3Model.setId(matcher.group("ID"));
			k3Model.setProject(matcher.group("PROJECT"));
			k3Model.setDetectedBy(matcher.group("DETECTEDBY"));
			k3Model.setCausedBy(matcher.group("CAUSEDBY"));
		}

		LOG.finest(buildFullDisplayname + "\t - After parsing line: " + k3Model);
		return k3Model;
	}
}
