package com.continental.xml_parser;

import static com.continental.MetricsPlugin.EMetricsModelType.EEPROM;
import static com.continental.MetricsPlugin.EMetricsModelType.RAM;
import static com.continental.MetricsPlugin.EMetricsModelType.ROM;
import static com.continental.utilities.GlobalProperties._1024;
import static com.continental.utilities.GlobalProperties._KEY_AVAILABLE_EEPROM;
import static com.continental.utilities.GlobalProperties._KEY_AVAILABLE_RAM;
import static com.continental.utilities.GlobalProperties._KEY_AVAILABLE_ROM;
import static com.continental.utilities.GlobalProperties._KEY_MEMORY_OBJECT_EEPROM;
import static com.continental.utilities.GlobalProperties._KEY_MEMORY_OBJECT_RAM;
import static com.continental.utilities.GlobalProperties._KEY_MEMORY_OBJECT_ROM;
import static com.continental.utilities.GlobalProperties._KEY_USED_EEPROM;
import static com.continental.utilities.GlobalProperties._KEY_USED_RAM;
import static com.continental.utilities.GlobalProperties._KEY_USED_ROM;

import java.io.File;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.PropertiesReader;

import hudson.model.Run;

public class MemoryReportsParser extends AbstractParser {

	public MemoryReportsParser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build,MetricsModel metricsModel) {
		super(projectMetricsFile, propertiesReader, build, metricsModel);
	}

	@Override
	protected void extractValuesFromXML() {
		extractRAMValuesFromXML();
		extractROMValuesFromXML();
		extractEEPROMValuesFromXML();
	}

	private void extractEEPROMValuesFromXML() {
		metricsModel.addMetrics(EEPROM, build.getNumber(),parser.parseWithXPath(projectMetricsFile,propertiesReader.readFromProperties(_KEY_AVAILABLE_EEPROM)) / _1024,totalMemory("EEPROM"));
	}

	private void extractRAMValuesFromXML() {
		metricsModel.addMetrics(RAM, build.getNumber(),parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_AVAILABLE_RAM)) / _1024, totalMemory("RAM"));
	}

	private void extractROMValuesFromXML() {
		metricsModel.addMetrics(ROM, build.getNumber(),parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_AVAILABLE_ROM)) /_1024, totalMemory("ROM"));
	}

	// available memory is defined : sum of memory object+ used memory: memory
	// obj memory on oy ax
	private double totalMemory(String memory) {
		double memoryObject = 0.0;
		double totalMemoryObject = 0.0;

		if ("RAM".equals(memory)) {
			memoryObject = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_MEMORY_OBJECT_RAM)) / _1024;
			totalMemoryObject = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_USED_RAM)) / _1024;
		} else {
			if ("ROM".equals(memory)) {
				memoryObject = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_MEMORY_OBJECT_ROM)) / _1024;
				totalMemoryObject = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_USED_ROM)) / _1024;
			} else {
				if ("EEPROM".equals(memory)) {
					memoryObject = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_MEMORY_OBJECT_EEPROM)) / _1024;
					totalMemoryObject = parser.parseWithXPath(projectMetricsFile, propertiesReader.readFromProperties(_KEY_USED_EEPROM)) / _1024;
				}
			}
		}
		
		double totalAvailableMemory = (memoryObject + totalMemoryObject);
		return Math.round(totalAvailableMemory * 100.0) / 100.0;
	}
}
