package com.continental.xml_parser;

import static com.continental.MetricsPlugin.EMetricsModelType.ELOC_CODE;
import static com.continental.utilities.GlobalProperties._KEY_ELOCNONSAFETY;
import static com.continental.utilities.GlobalProperties._KEY_ELOCSAFETY;

import java.io.File;

import com.continental.MetricsPlugin.MetricsModel;
import com.continental.utilities.PropertiesReader;

import hudson.model.Run;

public class ElocParser extends AbstractParser {

  public ElocParser(File projectMetricsFile, PropertiesReader propertiesReader, Run<?, ?> build,
      MetricsModel metricsModel) {
    super(projectMetricsFile, propertiesReader, build, metricsModel);

  }

  @Override
  protected void extractValuesFromXML() {

    metricsModel.addMetrics(ELOC_CODE, build.getNumber(),
        parser.parseWithXPath(projectMetricsFile,
            propertiesReader.readFromProperties(_KEY_ELOCNONSAFETY)),
        parser.parseWithXPath(projectMetricsFile,
            propertiesReader.readFromProperties(_KEY_ELOCSAFETY)));
  }

}
