// Callback that creates and populates a data table,
// instantiates the pie chart, passes in the data and
// draws it.

function drawCharts(data,options,chartContainer,chartType,groupsArray,labelName,colorPattern) {

	switch(chartContainer)
	{
	
	case "k5Chart_div":
		
		var chart = c3.generate({
			bindto: "#"+chartContainer,
				
			    data: {
			    	x: 'BUILD',
			        columns: data,
			        groups:groupsArray,
			        type: chartType
			    },
			    
			    axis: {
			    	x: {
			    		type: 'category',
			    		label: 'BUILDS',
			    		tick: {
			    				culling: {max:50},
			    				rotate: 90,
			    				multiline: false,
			    				fit: true
			    			},
			    		height:100
			    	},
			    	y: {
			    		max:100,
			    		label: {
			    			text: labelName,
			    			position: 'outer-center'
			    		},
			    		padding: {
			    					bottom:0
			    				}
			    	}
			    },
			    
			    grid : {
			    	 y: { 
			    		 lines: [
			    		         {value: 85,text :'Red Limit : below 85%',position: 'middle',class:'red'},
			    		         {value: 95,text :'Green Limit : above 95%',position: 'middle',class:'green'}
			    		         ]
			    		 }
			    },
			    
			    zoom: {
			    	enabled: true
			    },
			    
			    color: {
			    	pattern: colorPattern
			    },
			    
			    legend: {
    				position: 'right'
				},
							
				padding: {
			    	bottom:40,
			    	top:10
			    }
			});	 
		break;
	case "cycloComplexityChart_div":

	if(colorPattern != "") {
			var chart = c3.generate({
				bindto: "#"+chartContainer,
				
			    data: {
			    	x: 'BUILD',
			        columns: data,
			        groups:groupsArray,
			        type: chartType
			    },
			    
			    axis: {
			    	x: {
			    		type: 'category',
			    		label: 'BUILDS',
			    		tick: {
			    				culling: {max:50},
			    				rotate: 90,
			    				multiline: false,
			    				fit: true
			    			},
			    		height:100
			    	},
			    	y: {
			    		label: {
			    			text: labelName,
			    			position: 'outer-center'
			    		},
			    		padding: {
			    					bottom:0
			    				}
			    	}
			    },
			 
			    zoom: {
			    	enabled: true
			    },
			    
			    color: {
			    	pattern: colorPattern
			    },
			    
			    legend: {
    				position: 'right'
				},
				
				padding: {
			    	bottom:40,
			    	top:10
			    },
			    tooltip: {
		        format: {
		            value: function(value) {
		                return d3.format(",.2f")(value)
		            }
		        }
		    }
			 });
			}
			    break;
	
	case "k2Chart_div":
		
		var chart = c3.generate({
			bindto: "#"+chartContainer,
				
			    data: {
			    	x: 'BUILD',
			        columns: data,
			        groups:groupsArray,
			        type: chartType
			    },
			    
			    axis: {
			    	x: {
			    		type: 'category',
			    		label: 'BUILDS',
			    		tick: {
			    				culling: {max:50},
			    				rotate: 90,
			    				multiline: false,
			    				fit: true
			    			},
			    		height:100
			    	},
			    	y: {
			    		label: {
			    			text: labelName,
			    			position: 'outer-center'
			    		},
			    		padding: {
			    					bottom:0
			    				}
			    	}
			    },
			    
			    grid : {
			    	 y: { 
			    		 lines: [
			    		         {value: 0.001,text :'K2 Limit:0.001',position: 'middle',class:'red'}
			    		         ]
			    		 }
			    },
			    
			    colors: {
			    	'Label:K2 Limit' : '#ff0000'
			    },
			    
			    zoom: {
			    	enabled: true,
			    	rescale: true
			    },
			    
			    color: {
			    	pattern: colorPattern
			    },
			    
			    legend: {
    				position: 'right'
				},
				
				padding: {
			    	bottom:40
			    },
			    
				tooltip: {
				  format: {
						value: function (value, ratio, id) {
						var format = d3.format(',');
						return value;
						}
					}
				}
			});
		break;

	default:
		
		if(colorPattern != "") {
			var chart = c3.generate({
				bindto: "#"+chartContainer,
				
			    data: {
			    	x: 'BUILD',
			        columns: data,
			        groups:groupsArray,
			        type: chartType
			    },
			    
			    axis: {
			    	x: {
			    		type: 'category',
			    		label: 'BUILDS',
			    		tick: {
			    				culling: {max:50},
			    				rotate: 90,
			    				multiline: false,
			    				fit: true
			    			},
			    		height:100
			    	},
			    	y: {
			    		label: {
			    			text: labelName,
			    			position: 'outer-center'
			    		},
			    		padding: {
			    					bottom:0
			    				}
			    	}
			    },
			 
			    zoom: {
			    	enabled: true
			    },
			    
			    color: {
			    	pattern: colorPattern
			    },
			    
			    legend: {
    				position: 'right'
				},
				
				padding: {
			    	bottom:40,
			    	top:10
			    }
			});
		}
	}				
}