package com.conti.jira.api;

import com.atlassian.jira.rest.client.api.JiraRestClient;
import com.atlassian.jira.rest.client.api.JiraRestClientFactory;
import com.atlassian.jira.rest.client.api.domain.User;
import com.atlassian.jira.rest.client.internal.async.AsynchronousJiraRestClientFactory;
import com.atlassian.jira.rest.client.api.domain.IssueType;
import com.atlassian.jira.rest.client.api.domain.IssueField;
import com.atlassian.jira.rest.client.api.domain.Project;
import com.atlassian.jira.rest.client.api.domain.BasicProject;
import com.atlassian.jira.rest.client.api.domain.Issue;
import com.atlassian.jira.rest.client.api.domain.BasicIssue;
import com.atlassian.jira.rest.client.api.domain.SearchResult;
import com.atlassian.util.concurrent.Promise;
import org.codehaus.jettison.json.JSONObject;

import java.net.URI;


public class App 
{

	    public static void main(String[] args) throws Exception
	    {
	    	
	        JiraRestClientFactory factory = new AsynchronousJiraRestClientFactory();
	        URI uri = new URI(args[0]);
	        JiraRestClient client = factory.createWithBasicHttpAuthentication(uri, args[1], args[2]);

	        // Invoke the JRJC Client
	        Promise<User> promise = client.getUserClient().getUser(args[1]);
	        User user = promise.claim();

	        
	        Promise<SearchResult> searchJqlPromise = client.getSearchClient().searchJql(args[3],Integer.valueOf(10000),null,null);
	        
	        Iterable<Issue> issues = searchJqlPromise.claim().getIssues();
	        
	        System.out.println("Generating Report...\n\n\n\n");
	        System.out.println("\"ID\",\"Project\",\"Detected by\",\"Caused by\",");
	        
	        /*
	         * Iterate through the retrieved issues storing the 'Caused by' and 'Detected by' issue fields
	         */
	        		
	        for (Issue issue : issues) {
	        	
	        	JSONObject detectedBy = (JSONObject)issue.getField("customfield_10602").getValue();
	        	JSONObject causedBy = (JSONObject)issue.getField("customfield_10601").getValue();
	        	
	        	System.out.format("\"%d\",\"%s\",\"%s\",\"%s\",\n",issue.getId(),issue.getProject().getName(),detectedBy != null ? detectedBy.getString("value") : "" , causedBy != null ? causedBy.getString("value") : "");
	        	
	        }
	   
	        System.exit(0);
	    }
}
